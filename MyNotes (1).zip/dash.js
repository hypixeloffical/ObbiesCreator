document.addEventListener('DOMContentLoaded', function () {
  const button = document.getElementById('save1b');
  const keyInp = document.getElementById('key');
  const limitInp = document.getElementById("warn-limit")

  button.addEventListener('click', function () {
    const key = keyInp.value;
    const limit = limitInp.value;

    const data = { key: key, warnlimit: limit };
    console.log('Test');
    console.log(key);
    console.log(limit);
    if (!isNaN(parseInt(yourString))) {
      fetch('https://mynotes.hpyxiel.repl.co/set_warn_limit', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(data),
        })
        .then(response => {
          if (response.ok) {
            return response.json();
          } else {
            throw new Error('Network response was not ok');
          }
        })
        .then(responseData => {
          console.log('Server Response:', responseData);
        })
        .catch(error => {
          console.error('Error:', error);
        });
    } else {
      alert('Please enter a valid number');
    }
  });
});
