from threading import Thread

from flask import Flask, render_template, send_file

from bot import boot
import os

app = Flask(__name__)
@app.route('/')
def igotkilled():
  return "I officially got stabbed by :GetFather()" # why you here  #because i am yes

@app.route('/dashboard')
def home():
  with app.app_context():
    return render_template('dashboard.html')

@app.route('/dash.css')
def dashcss():
  with app.app_context():
    return send_file('dash.css')

@app.route('/dash.js')
def dashjs():
  with app.app_context():
    return send_file('dash.js')

def run():
  with app.app_context():
    app.run(host='0.0.0.0', port=6060)

t = Thread(target=run)
t.start()
boot()