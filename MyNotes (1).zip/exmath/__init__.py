def in_range(num: int, pos: int, range: int) -> bool:
  """
  Checks if a number is in a range specified by user.
  """
  return num > pos - range and num < pos + range