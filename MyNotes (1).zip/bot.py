bb = 0 
from replit import db


def boot():
  import asyncio
  import os
  import re
  import random
  import time
  import discord
  import datetime
  import requests
  from discord.ext import commands
  import fnmatch
  import aiohttp
  from aiohttp.client import ClientSession
  from io import BytesIO
  import string
  from exmath import in_range
  from datetime import datetime, timedelta
  intents = discord.Intents(webhooks=True)
  bot_id = 1216271716175839236
  bot_id_str = "1216271716175839236"
  me_id = 1068520478198743110
  me_id_str = "1068520478198743110"
  trio = [1090319633300598804, 1068520478198743110, 794350956300337215]
  
  allowidish = [me_id]

  def toEpoch(dt):
    return (str((time.mktime(dt.timetuple())))).replace(".0", "")

  help_library = {
      "moderation": {
          "ban": "Bans a user from the server. ",
          "unban": "Unbans a user from the server.",
          "kick": "Kicks a user from the server.",
          "mute": "Mutes a user in the server.",
          "unmute": "Unmutes a user in the server.",
          "clear": "Clears a specified amount of messages.",
          "speciclear":
          "Clears a specified amount of messages from a specified user.",
          "warn": "Warns a user in the server.",
          "getWarns": "Checks the warns of a user in the server.",
          "wipeWarns": "Clears the warns of a user in the server.",
          "softMute": "Soft mutes a user in the server.",
          "unsoftMute": "Unsoft mutes a user in the server.",
          "talk": "Talks the bot in the server.",
          "warnLimit": "Sets the warn limit of the server.",
          "nuke": "Clears all messages from a channel",
          "purge": "Starts a purge",
          "emojiTest":
          "Allows you to test an emoji from another server that bot is in",
          "delach": "Deletes an achievement",
          "serverach": "Creates an achievement"
      },
      "games": {
          "rps": "Plays rock paper scissors with the bot (You can win XP!)",
          "oddoreven":
          "Play a round of odd or even with the bot (You can win XP!)",
          "guessingNumbers":
          "Play a round of guessing numbers (You can win XP!)",
          "pingpong": "Play a round of ping pong with the bot (You can win XP!)",
          "quickmaths": "Gives everyone a random question and whoever wins gets XP!"
      },
      "part": {
          "addPart": "Adds a part to the user.",
          "delPart": "Deletes a part from the user. (Wildcards allowed)",
          "wipeParts ": "Clears the parts of the user.",
          "script": "Gives you the script for the oc glitched parts panel",
          "ockey": "Gives you the key for the oc glitched parts panel"
      },
      "counting": {
          "setLast":
          "Sets last user that counted (can be used to count twice).",
          "setNumber": "Sets the current **counted** number.",
          "checknumber": "Checks the current **counted** number."
      },
      "other": {
          "help": "Shows this help message",
          "isBotUp": "Checks if the bot is up.",
          "setTotalId": "Sets current warn Id",
          "userInfo": "Checks info of an user",
          "serverInfo": "Checks info of the server",
          "ping": "Sends latency of the bot in ms",
          "startContest": "Makes a join button appear"
      },
      "trading": {
        "accept": "Accepts somebody's trade",
        "createTrade": "Creates a trade",
        "replyTrade": "Replies to a trade"
      },
      "general": {
          "serverInfo": "Shows info about the server",
          "sping": "Silent Pings an user"
      },
      "levels": {
          "addXP": "Adds the XP of an user",
          "removeXP": "Removes the XP of an user",
          "updateLevels":
          "Gets all the people in the server and sets their level depending on what roles they have",
          "setLevel": "Sets the users level: >COMMAND @user {level}",
          "leaderboard": "Displays the top 10 highest level users",
          "transfer": "Transfers a currency to a player e.g: level, xp"
      },
      "verification": {
          "unverify": "Unverifies yourself",
          "verify": "Verifies yourself",
          "verifyall": "Verifies all the people that arent verified",
          "unverifyall": "Unverifies all the people that are verified"
        
      }
  }

  class MyHelp(commands.HelpCommand):

    async def send_bot_help(self, mapping):
      await self.context.send(view=SelectView(180))

  class HelpSelect(discord.ui.Select):

    def __init__(self, children, timeout):
      options = [
          discord.SelectOption(label="Moderation",
                               emoji="<:trustedAdmin:1210322501096185877>",
                               description="Help about moderation commands"),
          discord.SelectOption(label="Counting",
                               emoji="<:counting:1216389952837910558>",
                               description="Help about counting commands"),
          discord.SelectOption(label="Part",
                               emoji="<:parts:1210345270517309441>",
                               description="Help about part commands"),
          discord.SelectOption(label="Other",
                               emoji="<:bot:1209908923847409734>",
                               description="Help about other commands"),
          discord.SelectOption(label="General",
                               emoji="💻",
                               description="Help about general commands"),
          discord.SelectOption(label="Levels",
                               emoji="<:verification:1210342706111451246>",
                               description="Help about level commands"),
          discord.SelectOption(
              label="Games",
              emoji="🎮",
              description="Help about what games you can play"),
          discord.SelectOption(
              label="Trading",
              emoji="🤝",
              description="Help's you on what to do on trades"),
          discord.SelectOption(
            label="Verify",
            emoji="<:success:1209918587112919161>",
            description="Everything about verification")
      ]
      super().__init__(placeholder="Select an option",
                       max_values=1,
                       min_values=1,
                       options=options)

    async def callback(self, interaction: discord.Interaction):
      embed = discord.Embed(title="Help",
                            description=f"{self.values[0]} Commands",
                            color=discord.Colour.gold())
      option = self.values[0]

      if option == "Moderation":
        l = help_library
        moderation = l["moderation"]
        for command in moderation:
          embed.add_field(name=command,
                          value=moderation[command],
                          inline=False)

        await interaction.response.edit_message(embed=embed)
      elif option == "Counting":
        l = help_library
        counting = l["counting"]
        for command in counting:
          embed.add_field(name=command, value=counting[command], inline=False)

        await interaction.response.edit_message(embed=embed)
      elif option == "Part":
        l = help_library
        part = l["part"]
        for command in part:
          embed.add_field(name=command, value=part[command], inline=False)

        await interaction.response.edit_message(embed=embed)
      elif option == "Other":
        l = help_library
        other = l["other"]
        for command in other:
          embed.add_field(name=command, value=other[command], inline=False)

        await interaction.response.edit_message(embed=embed)
      elif option == "General":
        l = help_library
        other = l["general"]
        for command in other:
          embed.add_field(name=command, value=other[command], inline=False)

        await interaction.response.edit_message(embed=embed)
      elif option == "Levels":
        l = help_library
        other = l["levels"]
        for command in other:
          embed.add_field(name=command, value=other[command], inline=False)

        await interaction.response.edit_message(embed=embed)
      elif option == "Games":
        l = help_library
        other = l["games"]
        for command in other:
          embed.add_field(name=command, value=other[command], inline=False)

        await interaction.response.edit_message(embed=embed)
      elif option == "Trading":
        l = help_library
        other = l["trading"]
        for command in other:
          embed.add_field(name=command, value=other[command], inline=False)

        await interaction.response.edit_message(embed=embed)
      elif option == "Verify":
        l = help_library
        other = l["verification"]
        for command in other:
          embed.add_field(name=command, value=other[command], inline=False)

        await interaction.response.edit_message(embed=embed)

  class SelectView(discord.ui.View):

    def __init__(self, timeout=180):
      super().__init__()
      self.add_item(HelpSelect(self.children, timeout))

  intents = discord.Intents.all()

  bot = commands.Bot(command_prefix='>',
                     intents=intents,
                     case_insensitive=True,
                     help_command=MyHelp())

  def is_integer(s):
    try:
      int(s)
      return True
    except ValueError:
      return False

  muted = []

  def is_allowed(ctx):
    target_role = discord.utils.get(ctx.guild.roles, name='Mod')
    author_role = discord.utils.get(ctx.author.roles, name='Mod')

    return (author_role
            and author_role >= target_role) or ctx.author.id == me_id

  def is_owner(ctx):
    target_role = discord.utils.get(ctx.guild.roles, name='Adminstrators')

    return target_role in ctx.author.roles or ctx.author.id == me_id

  def is_not(ctx):
    target_role = discord.utils.get(ctx.guild.roles, name='Mod')
    author_role = discord.utils.get(ctx.author.roles, name='Mod')

    a = author_role and author_role >= target_role
    if ctx.author.id in allowidish:
      return True
    else:
      return not a

  def is_allowed2(ctx):
    target_role = discord.utils.get(ctx.guild.roles, name='Certified Bugger')
    author_role = discord.utils.get(ctx.author.roles, name='Certified Bugger')

    return author_role and author_role >= target_role or ctx.author.id == me_id

  
    
  def is_allowed3(message):
    target_role = discord.utils.get(message.guild.roles, name='Super Mod')
    author_role = discord.utils.get(message.author.roles, name='Super Mod')

    return author_role and author_role >= target_role or (
        str(message.author.id) == me_id_str
        or str(message.author.id) == bot_id_str)
  @bot.event
  async def on_member_join(member):
      creation_time = member.created_at.replace(tzinfo=None)

      account_age = datetime.utcnow() - creation_time

      if account_age < timedelta(days=15):
        channel = await member.create_dm()
        await channel.send(f"Your account is too young to join {member.guild.name}, sorry!")
        await member.kick(reason="Account too young")
      else:
        channel = await member.create_dm()
        await channel.send(f"Welcome to OC glitchers!")
  @bot.event
  async def on_member_remove(member):  
    logger = "https://discord.com/api/webhooks/1177881438125826088/vGQ97psaeFQA1X0WAQHg3cYumVGKHSHhMqQa678bnUQGvE5DbDxmJN9afhIY66N-hOkz"  
    data = {
        "embeds": [{
            "title": "Member Left",  
            "author": {
                "name": member.name,  
                "icon_url": member.avatar.url  
            },
        }]
    }
    requests.post(logger, json=data)
    
      
  @bot.event
  async def on_ready():
    print(f'Logged in as {bot.user.name}')
    print(f'Client ID: {bot.user.id}')
    await bot.tree.sync()
    await bot.change_presence(activity=discord.Activity(
        type=discord.ActivityType.watching, name="the server"))

    for member in bot.get_guild(1134270208983445604).members:
      if discord.utils.get(bot.get_guild(1134270208983445604).roles,
                           name='Owners') in member.roles:
        allowidish.append(member.id)

  @bot.command(aliases=["adm", "anony", "anonymousdm", "anonymousdirectmessage"])
  @commands.check(is_allowed)
  async def anonyDM(ctx, user: discord.Member, message: str):
    channel = await user.create_dm()
    await channel.send("Someone used AnonymousDM to send you this message: " +
                       message)


  @bot.command(aliases=["tord"])
  async def truthordare(ctx, type: str):
    isgames = 0
    if str(ctx.channel.id) == "1193559922265305089":
      isgames = 1

    if isgames == 0:
      await ctx.reply(
          "This command is only available in <#1193559922265305089>")
      return
    veteran2 = discord.utils.get(ctx.author.guild.roles, name="Veteran II")
    if type == "truth":
      randomdare = random.choice(db["truth"])  # Select a random item from db["truth"]
      looped = 0

      for i, item in enumerate(db["truth"]):
          a = db["truth"][i]
          if item == randomdare:
              print(i)
              await ctx.send(f"{ctx.author.mention} {a}")
          looped += 1
    elif type == "dare":
      randomdare = random.choice(db["dares"])  # Select a random item from db["truth"]
      looped = 0

      for i, item in enumerate(db["dares"]):
          a = db["dares"][i]
          if item == randomdare:
              print(i)
              await ctx.send(f"{ctx.author.mention} {a}")
          looped += 1
    elif type == "adddare":
      if veteran2 in ctx.author.roles:
        await ctx.send("What dare do you want to add?")

        def check1(m):
          return m.author == ctx.author
        response1 = await bot.wait_for('message', check=check1)

        db["dares"].append(response1.content)
        await ctx.send(f"Added ({response1.content}) to dares")
      else:
        await ctx.send("You need to be veteran II to use this command")
        return 
    elif type == "addtruth":
      if veteran2 in ctx.author.roles:
        await ctx.send("What truth do you want to add?")

        def check1(m):
          return m.author == ctx.author
        response1 = await bot.wait_for('message', check=check1)

        db["truth"].append(response1.content)
        await ctx.send(f"Added ({response1.content}) to truth")
      else:
        await ctx.send("You need to be veteran II to use this command")
        return
     
      
      

    
  
  @bot.command()
  async def botCount(ctx, number: int):
    if number <= 0:
      await ctx.send("Too low")
      return
    isgames = 0
    if str(ctx.channel.id) == "1140300832181596280":
      isgames = 1

    if isgames == 0:
      await ctx.reply(
          "This command is only available in <#1140300832181596280>")
      return
    price = number*2
    await ctx.reply(f"Do you want to buy add {number} to counting, this will cost you {price} xp")
    def check(m):
      return m.author == ctx.author and m.channel == ctx.channel and m.content.lower(
      ) in ['y', 'n']

    try:
      response = await bot.wait_for('message', check=check, timeout=50)
    except asyncio.TimeoutError:
      await ctx.send("You took too long to respond.")
      return
    if response.content.lower() == 'y':
      ldata = db["levels"]
      udata = ldata[ctx.author.name]
      udata["xp"] -= price
      if udata["xp"] < 0:
        await ctx.send("Not enough XP")
        udata["xp"] += price
        return
      db['number'] += number
      db["last"] = "Bot"
      await ctx.send(f"The bot has added {number} to counting, you now have {udata['xp']}xp left")
      await ctx.send(f"The current number is {db['number']}, The next number is {db['number']+1}")
    else:
      await ctx.send("Purchase canceled")


  
      
      
    
  @bot.command()
  @commands.check(is_allowed)
  async def timeout(ctx, member: discord.Member, time: str, *, reason=None):
    if reason is None:
      reason = "No reason provided"
    time_p = "s"
    if time.endswith("s"):
      time_p = "s"
    elif time.endswith("m"):
      time_p = "m"
    elif time.endswith("h"):
      time_p = "h"
    elif time.endswith("d"):
      time_p = "d"
    elif time.endswith("w"):
      time_p = "w"

    if time_p == "s":
      time_c = int(time.replace("s", ""))
      await member.timeout(datetime.timedelta(seconds=time_c))
    elif time_p == "m":
      time_c = int(time.replace("m", ""))
      await member.timeout(datetime.timedelta(minutes=time_c))
    elif time_p == "h":
      time_c = int(time.replace("h", ""))
      await member.timeout(datetime.timedelta(hours=time_c))
    elif time_p == "d":
      time_c = int(time.replace("d", ""))
      await member.timeout(datetime.timedelta(days=time_c))
    elif time_p == "w":
      time_c = int(time.replace("w", ""))
      await member.timeout(datetime.timedelta(weeks=time_c))

    channel = await member.create_dm()
    await channel.send(
        f"You have been timed out in {ctx.guild.name} for {time} for the following reason: {reason}"
    )
    await ctx.send(
        f"{member.mention} has been timed out for {time} for the following reason: {reason}"
    )
      
  @bot.command()
  async def transfer(ctx, type: str, user: discord.Member, amount: int):
    ldata = db["levels"]
    udata = ldata[ctx.author.name]
  
   
    if type == "xp":
      await ctx.send(f"Do you want to transfer {amount} xp to **{user.name}**. Y for yes, N for no.")
      
      def check(m):
        return m.author == ctx.author and m.channel == ctx.channel and m.content.lower(
        ) in ['y', 'n']

      try:
        response = await bot.wait_for('message', check=check, timeout=50)
      except asyncio.TimeoutError:
        await ctx.send("You took too long to respond. Transfer cancled.")
        return
      if response.content.lower() == 'y':
        udata["xp"] -= amount
        ldata[user.name]["xp"] += amount
        await ctx.send(f"{ctx.author.mention} Transfered {amount} xp to {user.mention}")
      else:
        await ctx.send("Transfer cancled.")
    elif type == "level":
      if udata["level"] < amount:
        await ctx.send("Not enough levels")
        return
      await ctx.send(f"Do you want to transfer {amount} levels to **{user.name}**. Y for yes, N for no.")
      
      def check(m):
        return m.author == ctx.author and m.channel == ctx.channel and m.content.lower(
        ) in ['y', 'n']

      try:
        response = await bot.wait_for('message', check=check, timeout=50)
      except asyncio.TimeoutError:
        await ctx.send("You took too long to respond. Transfer cancled.")
        return
      
      if response.content.lower() == 'y':
        udata["level"] -= amount
        udata["req"] = udata["level"] * 20 + udata["level"]
        ldata[user.name]["level"] += amount
        ldata[user.name]["req"] = ldata[user.name]["level"] * 20 + ldata[user.name]["level"]
        await ctx.send(f"{ctx.author.mention} Transfered {amount} levels to {user.mention}")
    elif type == "gametokens" or type == "gametoken":
      ctx.reply(f"gametokens is not an available source right now")
    else:
      ctx.reply(f"not a valid source, current sources: xp, levels")
    
  @bot.event
  async def on_message(message):
    try:
      if message.channel.name == "webhooklogs":
        if message.author.bot:
          if '@everyone' in message.content or '@here' in message.content:
            await message.delete()
          log_channel = bot.get_guild(1134270208983445604).get_channel(1166447117775163463)
          await log_channel.send(message.content)
      print(f"{message.author} " + f"[{message.channel.name}] -->  " + message.content)
      print(message.attachments)
    except AttributeError:
      print(f"{message.author} " +
            f"[{message.channel.recipient.display_name}] -->  " +
            message.content)
    unverify = discord.utils.get(message.guild.roles, name="Unverified")
    verify = discord.utils.get(message.guild.roles, name="Verified")

    if verify in message.author.roles:
      if unverify in message.author.roles:
        await message.author.remove_roles(unverify)
        
# gamecommands = [">pingpong", ">guessingnumbers", ">rps", ">oddoreven", ">guessingnumber", ">guessnumber", ">guess", ">gn"]
    gamecommands = [">pingpong", ">rps", ">oddoreven"]
    gamedata = db["gametoken"]
    for element in gamecommands:
      if message.content.startswith(element):
        if str(message.author.id) == "1090319633300598804":
          gamedata[str(message.author.id)] += 1
          await message.channel.send("You gained a game token!")
          print(str(gamedata[str(message.author.id)]))
        rad = random.randint(1, 100)
        if rad <= 25:
          gamedata[str(message.author.id)] += 1
          await message.channel.send("You gained a game token!")
          print(str(gamedata[str(message.author.id)]))
      else:
        pass
    
    if db["quickmaths"]["Active"] == 1:
      if message.content == str(db["quickmaths"]["Answer"]):
        db["correctusers"][message.author.display_name] = message.author.display_name
    if "levels" not in db:
      db["levels"] = {}

    if message.content == "@random" and is_allowed(message):
      ctx = message
      active_members = [
          member for member in ctx.guild.members
          if member.status == discord.Status.online and member.id !=
          bot.user.id and member.id != message.author.id and not member.bot
      ]

      if active_members:
        random_user = random.choice(active_members)
        mes = await ctx.channel.send(f'{random_user.mention}')
        await asyncio.sleep(0.2)
        await mes.delete()
    try:
      await bot.process_commands(message)
    except Exception as e:
      await ctx.send("An error occurred: " + repr(e).replace("\\n", "\n"))
    if message.author != bot.user and str(message.author.id) in muted:
      await message.delete()

    gamedata = db["gametoken"]    
    if message.author.id not in gamedata:
      gamedata[message.author.id] = 0
    mod = discord.utils.get(message.guild.roles, name="Mod")
    if message.channel.name == "🚀𝘁𝗿𝗮𝗱𝗶𝗻𝗴":
      if mod in message.author.roles:
        return
      elif message.author.id == bot.user.id:
        return
      time.sleep(0.1)
      await message.delete()

    if str(message.channel.id) == "1188193557442461806":
      if message.author.id == bot.user.id:
        return

      if message.attachments:
        print("Adding Reaction")
        await message.add_reaction(":regional_indicator_w:1188193557442461806")
        await message.add_reaction(":regional_indicator_l:1128242899166989332")
    if message.channel.name == "purge" and str(
        message.author.id) not in allowidish and message.author in banning:
      await message.delete()
      await message.channel.send("You are safe now " + message.author.name)
      banning.remove(message.author)
    
    if str(message.channel.id) == "1140300832181596280" and str(
        message.author.id) not in allowidish:
      if is_integer(message.content) and int(
          message.content
      ) == db["number"] + 1 and message.author.name != db["last"]:
        await message.add_reaction("\U00002705")
        db["number"] = db["number"] + 1
        db["last"] = message.author.name
      elif is_integer(message.content) and int(message.content) != db["number"] + 1 and message.author.name != db["last"]:
        try:
          if not in_range(int(message.content), db["number"], 3):
            await message.author.timeout(datetime.timedelta(minutes=10))
            await message.channel.send(
                f"Muted {message.author.mention} for 10 minutes\nReason: Purposefully ruining the count"
            )
        except discord.errors.Forbidden:
          await message.channel.send("discord.Errors.Forbidden")
          pass
        await message.add_reaction("\U0000274C")
        ctx = message.channel
        await ctx.send(
            f"{message.author.mention} RUINED IT AT **{db['number']}**!! Next number is **1**. **Wrong Number**."
        )
        db["number"] = 0
        db["last"] = ""
      elif is_integer(message.content) and message.author.name == db["last"]:
        try:
          if not in_range(int(message.content), db["number"], 3):
            await message.author.timeout(datetime.timedelta(minutes=10))
            await message.channel.send(
                f"Muted {message.author.mention} for 10 minutes\nReason: Purposefully ruining the count"
            )
            
        except discord.errors.Forbidden:
          await message.channel.send("discord.Errors.Forbidden")
          pass
        await message.add_reaction("\U0000274C")
        ctx = message.channel
        await ctx.send(
            f"{message.author.mention} RUINED IT AT **{db['number']}**!! Next number is **1**. **You can't count two numbers in a row.**"
        )
        db["last"] = ""
        db["number"] = 0
      else:
        pass

    # A level system which if u send a message ur xp goes up and if u meet a special requirement u reach next level. (required xp is next-level * 20)
    xpboost = 0
    
    if not message.content.startswith(">"):
      leveldata = db["levels"]
      if message.author.name not in leveldata:
        leveldata[message.author.name] = {"level": 0, "xp": 1, "req": 2}
      else:
        if not message.author.bot:
          member = discord.utils.get(message.guild.roles, name="Member")
          collector = discord.utils.get(message.guild.roles, name="Member II")
          veteran = discord.utils.get(message.guild.roles, name="Veteran")
          veteran2 = discord.utils.get(message.guild.roles, name="Veteran II")
          elitemember = discord.utils.get(message.guild.roles, name="Elite member")
          veteran3 = discord.utils.get(message.guild.roles, name="Ancient Veteran")
          user = message.author
          userdata = leveldata[message.author.name]
          userdata["xp"] = userdata["xp"] + random.randint(1, 2) + (xpboost * 10)
          if userdata["level"] > 0:
            xpboost = 0
          if userdata["xp"] < 0:
            userdata["level"] = userdata["level"] - 1
            if userdata["level"] < 0:
              xpboost + 1
            elif userdata["level"] > 0:
              xpboost = 0
  
            if userdata["xp"] < 0:
              userdata["xp"] = userdata["xp"] + userdata["req"]
              userdata["req"] = userdata["level"] / 20 + userdata["level"]
            elif userdata["xp"] > 0:
              userdata["xp"] = userdata["xp"] - userdata["req"]
              userdata["req"] = userdata["level"] * 20 + userdata["level"]
  
            await message.channel.send(
                f"{message.author.mention} lost a level!")
            if userdata["level"] == 0:
              await user.remove_roles(member)
              await message.channel.send(
                  f"{message.author.mention} lost member role")
            elif userdata["level"] == 4:
              await user.remove_roles(collector)
              await message.channel.send(
                  f"{message.author.mention} lost Member II role")
            elif userdata["level"] == 9:
              await user.remove_roles(veteran)
              await message.channel.send(
                  f"{message.author.mention} lost veteran role")
            elif userdata["level"] == 19:
              await user.remove_roles(veteran2)
              await message.channel.send(
                  f"{message.author.mention} lost veteran 2 role")
            elif userdata["level"] == 34:
              await user.remove_roles(elitemember)
              await message.channel.send(
                  f"{message.author.mention} lost elite member role")
            elif userdata["level"] == 49:
              await user.remove_roles(veteran3)
              await message.channel.send(
                  f"{message.author.mention} lost veteran III role")
  
          if userdata["xp"] >= userdata["req"]:
            print(userdata["level"])
            print(userdata["xp"])
            userdata["level"] = userdata["level"] + 1
            userdata["xp"] = 0
            userdata["req"] = userdata["level"] * 20 + userdata["level"]
            await message.channel.send(
                f"{message.author.mention} Leveled up to level **{userdata['level']}**"
            )
            
            member = discord.utils.get(message.guild.roles, name="Member")
            collector = discord.utils.get(message.guild.roles, name="Member II")
            veteran = discord.utils.get(message.guild.roles, name="Veteran")
            veteran2 = discord.utils.get(message.guild.roles,name="Veteran II")
            elitemember = discord.utils.get(message.guild.roles,name="Elite member")
            veteran3 = discord.utils.get(message.guild.roles,name="Ancient Veteran")
            user = message.author
  
            if userdata["level"] >= 50 and veteran3 not in user.roles:
              await user.add_roles(veteran3)
              await message.channel.send(
                    f"Congrats, {message.author.mention} got Ancient Veteran role by reaching level **50**."
              )
            elif userdata["level"] >= 35 and elitemember not in user.roles:
              await user.add_roles(elitemember)
              await message.channel.send(
                    f"{message.author.mention} got elite member role by reaching level **35**."
              )
            elif userdata["level"] >= 20 and veteran2 not in user.roles:
              await user.add_roles(veteran2)
              await message.channel.send(
                    f"{message.author.mention} got veteran 2 role by reaching level **20**."
              )
            elif userdata["level"] >= 9 and veteran not in user.roles:
              await user.add_roles(veteran)
              await message.channel.send(
                    f"{message.author.mention} got veteran role by reaching level **9**."
              )
            elif userdata["level"] >= 5 and collector not in user.roles:
              await user.add_roles(collector)
              await message.channel.send(
                  f"{message.author.mention} got member II role by reaching level **5**."
              )
            elif userdata["level"] >= 5 and member not in user.roles:
              await user.add_roles(member)
              await message.channel.send(
                    f"{message.author.mention} got Member role by reaching level **5**."
              )

    # Basic AutoMod
    if not message.author.bot and len(message.mentions) >= 3:
      await message.delete()
      author = message.author
      await author.timeout(duration=datetime.timedelta(minutes=3),
                           reason="AutoMod: Mass Mention")
      await message.channel.send(
          f"{author.mention} Has been timed out for 3 minutes. **Reason**: \"AutoMod: Mass Mention\""
      )

    shortener_keywords = [
      'discord.gg/', 'top.gg/servers/', 'dsc.gg','bit.ly' 'grabify.link',
      't.ly', 'tinyurl.com', 'ow.ly', 'is.gd', 'tiny.cc', 'tinyurl.com',
      'ow.ly', 'bit.do', 'tiny.one', 'tiny.cc','bit.ly'
    ]

    banned_keywords = [
      'porn','strip','gay','lesbian','nigger'
    ]

    if any(keyword in message.content for keyword in banned_keywords):
      await message.delete()
      author = message.author
      mod = discord.utils.get(message.guild.roles, name="Mod")
      if mod in message.author.roles:
        return
      await author.timeout(duration=datetime.timedelta(minutes=5),reason="AutoMod: Blacklisted Words")
      await message.send(f"You have been timed out for 5 minutes. **Reason**: \"AutoMod: Blacklisted Words\"")
      await message.channel.send(f"{author.mention} has been timed out for 5 minutes for saying a black listed word")
    if any(keyword in message.content for keyword in shortener_keywords):
      if message.author.id == bot.user.id:
        return
      isgames = 0
      if str(message.channel.id) == "1203650274619826197":
        isgames = 1

      if isgames == 1:
        return
      mod = discord.utils.get(message.guild.roles, name="Mod")
      
      veteran2b  = discord.utils.get(message.guild.roles, name="Ancient Veteran")
  
      if veteran2b in message.author.roles:
        return
      if mod in message.author.roles:
        return
      await message.delete()
      author = message.author
      await author.timeout(duration=datetime.timedelta(minutes=5),
                           reason="AutoMod: Server Invites")
      await message.send("You have been timed out for 5 minutes for sending server invites not in the <#1203650274619826197> channel")
      await message.channel.send(
          f"{author.mention} Has been timed out for 5 minutes. **Reason**: \"AutoMod: Mass Mention\""
      )

    # Mysterious Skill thingy
    choice = ["nothing"] * 50 + ["c1", "c2", "c3", "c4", "c5", "c6"] * 10 + ["r1", "r2", "r3"] * 8 + ["u1", "u2", "u3", "u4", "u5"] * 6 + ["rr1", "rr2", "rr3"] * 5 + ["rc1", "rc2", "rc3", "rc4", "rc5", "rc6", "rc7"] + ["s1", "s2", "s3"]

    dataa = {
      "c1": {
        "emoji": "<:new_logo:1216107134102671463>",
        "name": "New Logo"
      },
      "c2": {
        "emoji": "<:Visual:1216110538157719623>",
        "name": "Visual Studio"
      },
      "c3": {
        "emoji": "<:grass:1216111526323163327>",
        "name": "Touch Grass"
      },
      "c4": {
        "emoji": "<:SmokingGoober:1206996940911415326>",
        "name": "Smoking Goober"
      },
      "c5": {
        "emoji": "<:OldLogo:1216114326033924216>",
        "name": "Old Logo"
      },
      "c6": {
        "emoji": "<:lowqualitytroll:1208143525762564186>",
        "name": "Troll"
      },
      "r1": {
        "emoji": "<:Mewing:1216116570443612170>",
        "name": "Mewing"
      },
      "r2": {
        "emoji": "<:FIREINTHEHOLE:1190727721836363876>",
        "name": "Fire in the Hole"
      },
      "r3": {
        "emoji": "<:WATERONTHEHILL:1216117704017051740>",
        "name": "Water on the hill"
      },
      "u1": {
        "emoji": "<:Mcdonaldes:1216121425262284970>",
        "name": "Mc Donaldes"
      },
      "u2": {
        "emoji": "<:kat:1216121437820030996>",
        "name": "Kat"
      },
      "u3": {
        "emoji": "<:mar0:1216122299678326974>",
        "name": "Maro"
      },
      "u4": {
        "emoji": "<:premiam:1216123786341122288>",
        "name": "Premiam"
      },
      "u5": {
        "emoji": "<:areyouseriousrn:1216106067285770310>",
        "name": "R u serious rn"
      },
      "rr1": {
        "emoji:": "<:Golden_Box:1216278402693337129>",
        "name": "Golden Box"
      },
      "rr2": {
        "emoji": "<:Serious:1216278449254039614>",
        "name": "Serious"
      },
      "rr3": {
        "emoji": "<:Smiley:1216278427536199750>",
        "name": "Smiley"
      }
    }

    current = random.choice(choice)
    if current == "nothing":
      return
    elif current == "nothing":
      return

  
  @bot.command()
  async def replytrade(ctx, message: str, trader: discord.Member):
    isgames = 0
    if str(ctx.channel.id) == "1170755673223602347":
      isgames = 1

    if isgames == 0:
      await ctx.reply(
          "This command is only available in <#1170755673223602347>")
      return

    await ctx.message.delete()
    
    await ctx.send(trader.mention + " Reply from "+ ctx.author.mention + ": " + message)
  @bot.command(aliases=["qm"])
  async def quickmaths(ctx):
    ldata = db["levels"]
    udata = ldata[ctx.author.name]
    qmdata = db["quickmaths"]

  
    if qmdata["Active"] == 1:
      ctx.send("There is already an ongoing quickmaths")
      return
    if udata["level"] < 7:
      await ctx.send("Command is only for veterans")
      return

    numbers = random.randint(2, 4)
    text = ""
    answer = ""
    def evaluate_expression(expression):
      try:
        return eval(expression)
      except ZeroDivisionError:
        return None
    for i in range(numbers):
      symbol = random.choice(["+", "-", "*", "/"])
      number = random.randint(1, 8)

      if i == numbers:
        text += f" {number}"
        answer += f" {number}"
      else:
        answer += f" {number} {symbol}"
      
    answer += f" {numbers}"
    text = answer
    await ctx.send(f"{ctx.author.mention} has started a **quick maths!**. Solve it quick! \n{answer}")
    answer = evaluate_expression(answer)
    
    qmdata["Active"] = 1
    qmdata["Answer"] = answer

    await asyncio.sleep(15)

    db["correctusers"] = []

    solvers = ""
    qmdata["Active"] = 0
    qmdata["Answer"] = 0
    looped = 0
    first = 24 + numbers
    second = 16 + numbers
    third = 4 + numbers
    for i in db["correctusers"]:
      reward = 2
      looped = looped + 1
      if looped == 1:
        ldata[i]["xp"] = ldata[i]["xp"] + first
        reward = first
      elif looped == 2:
        ldata[i]["xp"] = ldata[i]["xp"] + second
        reward = second
      elif looped == 3:
        ldata[i]["xp"] = ldata[i]["xp"] + third
        reward = third
      elif looped == 4:
        ldata[i]["xp"] = ldata[i]["xp"] + numbers
        reward = numbers
      solvers += f" {looped}: {i} ({reward} xp) \n"
    
    await ctx.send(f"Quick maths has ended, here are the results! \n  Question: {text} \n  Answer: {answer} \n **People who solved it: \n {solvers}**")

    db["correctusers"] = {}


  @bot.command(aliases=['addparts'])
  @commands.check(is_allowed2)
  async def addPart(ctx, user: discord.Member, part):
    if True:
      userid = str(user.id)
      if userid in db:
        parts = db[userid]
        if parts:
          parts_list = parts.split(", ")
          if part not in parts_list:
            parts_list.append(part)
            db[userid] = ", ".join(parts_list)
            #await ctx.send(f"Added part '{part}' to {user.name}'s parts.")

            inp = part.split(", ")
            text = ""
            for part in inp:
              text = text + part + "\n"
            descbody = f"""
            **Added Parts:**
            {text}
            """

    
            embed = discord.Embed(
                title="<:success:1209918587112919161> Operation Success",
                description=descbody)
          else:
            #await ctx.send(f"'{part}' already exists in {user.name}'s parts.")
            descbody = f"""
            Part already exists in {user.name}'s parts
            """
            embed = discord.Embed(
                title="<:cancel:1174614827470164049> Operation Failed",
                description=descbody)
            await ctx.send(embed=embed)
        else:
          db[userid] = part
          #await ctx.send(f"Added part '{part}' to {user.name}'s parts.")
          descbody = f"""
          **Added Parts:**
          {part}
          """
          embed = discord.Embed(
              title="<:success:1209918587112919161> Operation Success",
              description=descbody)
          await ctx.send(embed=embed)

      else:
        db[userid] = part
        descbody = f"""
        **Added Parts:**
        {part}
        """
        embed = discord.Embed(
            title="<:success:1209918587112919161> Operation Success",
            description=descbody)
        await ctx.send(embed=embed)

  @bot.command()
  @commands.check(is_allowed)
  async def delPart(ctx, user: discord.Member, *, pattern):
    if True:
      user_id = user.id
      if str(user_id).encode() in db:
        db_value = db[str(user_id)].split(", ")

        matching_parts = [
            part for part in db_value
            if fnmatch.fnmatchcase(part.lower(), pattern.lower())
        ]

        if matching_parts:
          rawMessages = []
          for part in matching_parts:
            db_value.remove(part)
            #await ctx.send(f"Deleted '{part}' from {user.name}'s data.")
            rawMessages.append(part)
          db[user_id] = ", ".join(db_value)
          messages = ""
          for message in rawMessages:
            messages = messages + message + "\n"
          descbody = f"""
                  **Parts that are deleted:**
                  {messages}
                  """
          embed = discord.Embed(
              title="<:success:1209918587112919161> Operation Success",
              description=descbody)
          await ctx.send(embed=embed)
        else:
          embed = discord.Embed(
              title="<:cancel:1174614827470164049> Operation Failed",
              description=f"No part matched '{pattern}'")
          await ctx.send(embed=embed)
      else:
        embed = discord.Embed(
            title="<:cancel:1174614827470164049> Operation Failed",
            description=f"{user.name} has no parts")
        await ctx.send(embed=embed)

  @bot.tree.command(name="test_slash",description="Slash command test") 
  async def slash_command(interaction:discord.Interaction):
    await interaction.response.send_message("Hello World!")
  
  @bot.command()
  async def getParts(ctx, user: discord.Member):
    parts = db.get(str(user.id))
    if parts is not None:
      partstr = ""
      parties = parts.split(", ")
      for part in parties:
        partstr = partstr + part + "\n"
      embed = discord.Embed(title="<:success:1209918587112919161> Here:",
                            description=f"""
      **Parts of {user.mention}:**
      {parties}
      """)
      await ctx.send(embed=embed)
    else:
      embed = discord.Embed(
          title="<:cancel:1174614827470164049> Operation Failed",
          description=f"No parts were found for {user.name}")
      await ctx.send(embed=embed)

  
    
  @bot.command()
  @commands.check(is_allowed)
  async def kick(ctx, user: discord.Member, *, reason=None):
    await user.kick(reason=reason)
    channel = await user.create_dm()
    embed = discord.Embed(
        title="<:success:1209918587112919161> Operation Success",
        description=
        f"**Result:**\n{user.mention} was successfully kicked out from **{ctx.guild.name}**"
    )
  
  @bot.command()
  async def wipeData(ctx, user: discord.Member):
    if ctx.author.id in allowidish:

      def check(m):
        return m.author == ctx.author and m.content.lower() in ['y', 'n']

      await ctx.send(
          f"Are you sure you want to wipe all of the data from {user.name}? (Y/N)"
      )
      response = await bot.wait_for('message', check=check)
      if response.content.lower() == 'y':
        if str(user.id).encode() in db:
          del db[str(user.id).encode()]
        embed = discord.Embed(
            title="<:success:1209918587112919161> Operation Success",
            description=f"**Result:**\n{user.mention}'s data has been wiped")
        await ctx.send(embed=embed)
      else:
        embed = discord.Embed(
            title="<:cancel:1174614827470164049> Operation Aborted",
            description="")
        await ctx.send(embed=embed)

  @bot.command()
  @commands.check(is_owner)
  async def superping(ctx, member: discord.Member):
    for i in range(10):
      await ctx.send(member.mention)

  @bot.command()
  async def whisper(ctx, member: discord.Member, message: str):
    guild = ctx.guild
    await guild.create_text_channel()

  @bot.command()
  async def isBotUp(ctx):
    await ctx.send("Here I am")

  @bot.command()
  async def softMute(ctx, user: discord.Member):
    if ctx.author.id == me_id:
      muted.append(str(user.id))
      mutedd = await ctx.send(f"{user.name} has been soft-muted")
      await asyncio.sleep(5)
      await ctx.message.delete()
      await mutedd.delete()
  @bot.command()
  async def mew(ctx):
    with open('mewing.mp4', 'rb') as f:
      picture = discord.File(f)
      await ctx.message.delete()
      await ctx.send("🤫🧏‍♂️")
      await ctx.send(file=picture)
  @bot.command()
  @commands.check(is_allowed)
  async def unsoftMute(ctx, user: discord.Member):
    if ctx.author.id == me_id:
      if str(user.id) in muted:
        muted.remove(str(user.id))
        unmuted = await ctx.send("Unmuted " + user.name)
        await asyncio.sleep(5)
        await unmuted.delete()
        await ctx.message.delete()
      else:
        notmuted = await ctx.send("User is not muted")
        await asyncio.sleep(3)
        await notmuted.delete()
        await ctx.message.delete()

  @bot.command()
  @commands.check(is_allowed)
  async def ban_id(ctx, user: int, *, reason=None):
    user = await bot.fetch_user(user)
    await ctx.guild.ban(user, reason=reason)
    await ctx.send(f"{user.name} has been banned")


  
  @bot.command()
  @commands.check(is_allowed)
  async def ban(ctx, user: discord.Member, reason: str):
    logs = bot.get_channel(1193558074645041152)
    if user.id in allowidish:
      await ctx.send("You can't ban my developer.")
      channel = await ctx.author.create_dm()
      with open('images.jpeg', 'rb') as f:
        picture = discord.File(f)
        await channel.send(file=picture)
      if ctx.author.id not in allowidish:
        await ctx.author.ban(reason="LOOOOOSER")
        await logs.send("an idiot tried to ban an owner")
    else:
      await user.ban(reason=reason or "No reason provided")
      embed = discord.Embed(
          title="<:success:1209918587112919161> Operation Success",
          description=f"""
      **Result:**
      {user.mention} was successfully banned.
      Unban discriminator: **{user.id}**
      """)
      await ctx.send(embed=embed)
      logs = bot.get_channel(1193558074645041152)
      await logs.send(embed=embed)
      channel = await user.create_dm()
      await channel.send(
          f"You were banned from {ctx.message.guild.name} because: '{reason}'")

  @bot.command(aliases=["exploitloadstring"])
  async def script(ctx):
    isgames = 0
    if str(ctx.channel.id) == "1174460991556305136":
      isgames = 1

    if isgames == 0:
      await ctx.reply(
          "This command is only available in <#1174460991556305136>")
      return
    channel = await ctx.author.create_dm()
    key = requests.get(
        url="https://raw.githubusercontent.com/kw-roblox/OCkey/main/Loadstring.lua?token=GHSAT0AAAAAACKJTBWP4PIP6BSPDBYJSN5GZPZIJQQ")
    key = key.text
    if key == "404: Not Found":
      await ctx.send("Error: Link to script can't to be found")
      return
    print(key)
    await channel.send(f'loadstring(game:HttpGet({key})()')
    await channel.send("**Make sure the script the bot sent you only takes up 1 line as the bot sometimes makes it 2 lines** ")


  
  @bot.event
  async def on_webhooks_update(channel):
    print(f"A webhook was deleted in channel: {channel.name}")
    async for entry in channel.guild.audit_logs(action=discord.AuditLogAction.webhook_delete):
        webhook = entry.target
        print(f"The webhook was deleted by: {entry.user}")
        break  # We only need the first entry, which corresponds to the most recent deletion
    
  @bot.command()
  async def test(ctx):
    key = requests.get(
      url="https://raw.githubusercontent.com/kw-roblox/OCkey/main/Testing.py")
    key = key.text
    key = key.replace("\"", "").replace("return ", "")
    await ctx.reply(f"{key}")
  @bot.command(aliases=["okiedokie"])
  async def ocKey(ctx):
    isgames = 0
    if str(ctx.channel.id) == "1174460991556305136":
      isgames = 1

    if isgames == 0:
      await ctx.reply(
          "This command is only available in <#1174460991556305136>")
      return
    channel = await ctx.author.create_dm()
    key = requests.get(
        url="https://raw.githubusercontent.com/kw-roblox/OCkey/main/Key.lua?token=GHSAT0AAAAAACKJTBWOILTHWK6TFATHQICCZPXDXVA")
    key = key.text
    key = key.replace("\"", "").replace("return ", "")
    if key == "404: Not Found":
      await ctx.send("Error: Link to the key can't to be found")
      return
    await channel.send(f"Here is the key to OC Glitched Pannel: {key}")

  @bot.command()
  @commands.check(is_allowed)
  async def unban(ctx, user1: int):
    user = await bot.fetch_user(user1)
    await bot.get_guild(1134270208983445604).unban(user)
    await ctx.send(f"<@{user1}> unbanned successfully.")

  @bot.command()
  @commands.check(is_allowed)
  async def nuke(ctx):

    def check(m):
      return m.author == ctx.author and m.content.lower() in ['y', 'n']

    await ctx.send(
        "Are you sure you want to wipe all of messages from this channel(Y/N)")
    response = await bot.wait_for('message', check=check)
    if response.content.lower() == 'y':
      guild = ctx.message.guild
      category = ctx.message.channel.category
      await guild.create_text_channel(ctx.message.channel.name,
                                      category=category)
      await ctx.message.channel.delete()
    else:
      await ctx.send("Canceled Successfuly.")

  async def emptyWarnTemplate(ctx, user: discord.Member):
    if not db[user.name]:
      db[user.name] = {}

  @bot.command()
  async def unverify(ctx):
    logchannel = discord.utils.get(ctx.guild.channels, name="logs")
    unverify = discord.utils.get(ctx.guild.roles, name="Unverified")
    verify = discord.utils.get(ctx.guild.roles, name="Verified")
    if ctx.channel.id != 1140308985765965985:
      await ctx.send("You can only use this command in: <#1140308985765965985>")
      return
    elif unverify in ctx.author.roles:
      await ctx.send("You need to be verified to use this command.")
      return

    
    await ctx.reply("Are you sure you want to unverify? (Y/N)")

    def check(m):
      return m.author == ctx.author and m.channel == ctx.channel and m.content.lower(
      ) in ['y', 'n']

    try:
      response = await bot.wait_for('message', check=check, timeout=50)
    except asyncio.TimeoutError:
      await ctx.send("You took too long to respond.")
      return
    if response.content.lower() == 'y':
      await logchannel.send(f"Unverified {ctx.author.mention}")
      await ctx.author.remove_roles(verify)
      await ctx.author.add_roles(unverify)
    else:
      await ctx.send("Cancled unverification")
      
  @bot.command()
  async def verify(ctx):
    approved = 0
    blacklist = [
      "kw_roblox",
      "kw_robIox",
      "kw roblox",
      "kw_rodblox",
      "kw roIox",
      "kw rodblox",
      
    ]
    if ctx.channel.id != 1210348209399005276:
      await ctx.send("You can only use this command in: <#1210348209399005276>")
      return
    logchannel = discord.utils.get(ctx.guild.channels, name="logs")
    mod = discord.utils.get(ctx.guild.roles, name="Mod")
    unverify = discord.utils.get(ctx.guild.roles, name="Unverified")
    verify = discord.utils.get(ctx.guild.roles, name="Verified")
    if unverify not in ctx.author.roles or verify in ctx.author.roles:
      await ctx.send("You are already verified.")
      return
    channel = await ctx.author.create_dm()
    def randstring(length=10):
      valid_letters='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789{}[]()\\/+-_*#$@!?|~^&ඞඩධවැ☆★ｍｎｏｐｑ雄鸡𝐀𝓑𝐜'
      return ''.join((random.choice(valid_letters) for i in range(length)))

    number = randstring(20)
    print(number)
    await channel.send(f"Your verification code is: {number}")
    await ctx.reply("Please respond with the code you received in your DM.")
    
    def check(m):
      return m.author == ctx.author and m.content == number

    def check1(m):
      return m.author == ctx.author
      
    response = await bot.wait_for('message', check=check)
    if response.content == number:
      await ctx.reply("Now please enter the nickname you want to be called as.")
      response1 = await bot.wait_for('message', check=check1)
      member = ctx.author
      for i in blacklist:
        if response1.content.lower() == i:
          if mod in ctx.author.roles:
            print("approved")
          else:
            approved = 1


      if approved == 0:
        await member.remove_roles(unverify)
        await member.edit(nick=response1.content)
        await logchannel.send(f"**{ctx.author.name}** has been verified.")
      else:
        await ctx.send("You cannot use that nickname.")
        approved = 0
    

    
  @bot.command(aliases=["checkcount", "currentnumber", "currentcount"])
  async def checknumber(ctx):
    isgames = 0
    if str(ctx.channel.id) == "1140300832181596280":
      isgames = 1

    if isgames == 0:
      await ctx.reply(
          "This command is only available in <#1140300832181596280>")
      return
    number = db["number"]
    await ctx.reply("The current number is " + str(number) + ", The next number is " + str(number+1))
 
    
  @bot.command()
  async def coinflip(ctx, bet: int, choice: str):
    isgames = 0
    if str(ctx.channel.id) == "1193559922265305089":
      isgames = 1

    if isgames == 0:
      await ctx.reply(
          "This command is only available in <#1193559922265305089>")
      return
    valid = 0
    if choice.lower() == "heads" or choice.lower() == "tails":
      valid = 1
    if valid == 0:
      await ctx.reply("Invalid Choice. Choose either heads or tails")
      return
    embed = discord.Embed(
      title="Coin flip",
      description=f"{ctx.author.mention} Started a coin flip!")
    embed.add_field(name=f"Prize:", value=f"{bet} xp")
    embed.add_field(name=f"Choice:", value=choice)
    id = str(random.randint(1, 10000000))
    id = id + str(random.randint(1, 10000000))
    embed.add_field(name=f"Join ID:", value=id)
    message = await ctx.send(embed=embed)
    db[id] = [
        f"https://discord.com/channels/{ctx.guild.id}/{ctx.channel.id}/{message.id}", ctx.author.id, choice, bet
    ]
  
    
  @bot.command()
  @commands.check(is_allowed)
  async def warn(ctx, user: discord.Member, *, reason=None):
    logs = bot.get_channel(1193558074645041152)
    if reason is None:
      reason = "No reason provided"
    if user.name not in db:
      db[user.name] = {}

    await emptyWarnTemplate(ctx, user)
    channel = await user.create_dm()
    await channel.send(
        f"You were warned in {ctx.message.guild.name} because: {reason}")

    totalId = str(db["totalId"])
    warnlimit = 10

    if len(db[user.name]) >= warnlimit and ctx.author.id in allowidish:
      channel = await user.create_dm()
      await channel.send(
          f"You were banned from {ctx.message.guild.name} because you reached the warning limit of {str(warnlimit)}  lmaoooo"
      )
      await ctx.send(f"{user.mention} has reached the warning limit.")
      await logs.send(f"{user.mention} has been banned. Reason: Reached warning limit")
      await user.ban(reason="Reached warning limit.")
      del db[user.name]
    elif len(db[user.name]) == 3 and ctx.author.id in allowidish:
      
      channel = await user.create_dm()
      await channel.send(
          f"You have been muted for 1 day in {ctx.message.guild.name} for reaching 3 warns."
      )
      await ctx.send(f"{user.mention} has been muted for 3 day for reaching 3 warns.")
      await logs.send(f"{user.mention} has been muted for 3 days.")
      await user.timeout(datetime.timedelta(days=3))

    elif len(db[user.name]) == 5 and ctx.author.id in allowidish:
      randommutetime = random.randint(4, 8)
      channel = await user.create_dm()
      await logs.send(f"{user.mention} has been muted for 5 days.")
      await channel.send(
          f"You have been muted for {randommutetime} days in {ctx.message.guild.name} for reaching 5 warns."
      )
      await ctx.send(f"{user.mention} has been muted for {randommutetime} days for reaching 5 warns.")
      await user.timeout(datetime.timedelta(days=randommutetime))
    elif len(db[user.name]) == 7 and ctx.author.id in allowidish:
      await logs.send(f"{user.mention} has muted for a week")
      channel = await user.create_dm()
      await channel.send(
          f"You have been muted for 1 week in {ctx.message.guild.name} for reaching 7 warns."
      )
      await ctx.send(f"{user.mention} has been muted for 1 week for reaching 7 warns.")
      await user.timeout(datetime.timedelta(weeks=1))

    elif len(db[user.name]) == 9 and ctx.author.id in allowidish:
      channel = await user.create_dm()
      await logs.send(f"{user.mention} has been muted for 5 days and has lost 10 levels")
      await channel.send(
          f"You have been muted for 5 days in {ctx.message.guild.name} for reaching 9 warns and lost 10 levels"
      )
      await ctx.send(f"{user.mention} has been muted for 5 days for reaching 9 warns and lost 10 levels")
      await user.timeout(datetime.timedelta(days=5))
      leveldata = db["levels"]
      userdata = leveldata[ctx.author.name]
      userdata["level"] = userdata["level"] - 10

    user_name = user.name

    warning = {
        "id": totalId,
        "reason": reason,
        "moderator": ctx.author.name,
    }

    db[user_name][totalId] = warning

    embed = discord.Embed(title="Warn Case " + totalId,
                          description="Total Id " + totalId,
                          color=discord.Colour.gold())
    embed.add_field(name="User", value=user.mention, inline=False)
    embed.add_field(name="Moderator", value=ctx.author.mention, inline=False)
    embed.add_field(name="Reason", value=reason, inline=False)

    await ctx.send(embed=embed)

    if str(ctx.channel.id) != "1193558074645041152":
      channel = bot.get_channel(1193558074645041152)
      await channel.send(embed=embed)

    db["totalId"] += 1
    print(db[user_name][totalId])
    

  @bot.command()
  async def setTotalId(ctx, id: int):
    if ctx.author.id in allowidish:
      db["totalId"] = id
      message = await ctx.send("Set id to " + str(id))
      await asyncio.sleep(2)
      message.delete()

  @bot.command()
  @commands.check(is_allowed)
  async def clear(ctx, num_messages: int):
    if num_messages <= 0:
      await ctx.send("Please provide a valid number of messages to delete.")
      return

    await ctx.send(
        f"Are you sure you want to delete the last {num_messages} messages? (Y/N)"
    )

    def check(m):
      return m.author == ctx.author and m.channel == ctx.channel and m.content.lower(
      ) in ['y', 'n']

    try:
      response = await bot.wait_for('message', check=check, timeout=30)
    except asyncio.TimeoutError:
      await ctx.send("You took too long to respond. Deletion canceled.")
      return

    if response.content.lower() == 'y':
      await ctx.channel.purge(limit=num_messages + 4)
      await ctx.send(f"{num_messages} message(s) deleted.")
    else:
      await ctx.send("Deletion canceled.")
  @bot.command()
  @commands.check(is_allowed)
  async def gamegive(ctx, user: discord.Member, amount: int):
    db["gametoken"][str(user.id)] += amount
    
  @bot.command()
  @commands.check(is_allowed)
  async def speciclear(ctx, user: discord.Member, num_messages: int):
    if num_messages <= 0:
      await ctx.send("Please provide a valid number of messages to delete.")
      return

    await ctx.send(
        f"Are you sure you want to delete the last {num_messages} messages of {user.mention}? (Y/N)"
    )

    def check(m):
      return m.author == ctx.author and m.channel == ctx.channel and m.content.lower(
      ) in ['y', 'n']

    try:
      response = await bot.wait_for('message', check=check, timeout=30)
    except asyncio.TimeoutError:
      await ctx.send("You took too long to respond. Deletion canceled.")
      return

    if response.content.lower() == 'y':

      def is_target(msg):
        return msg.author == user


    
      deleted_messages = await ctx.channel.purge(limit=num_messages + 1, check=is_target)
      await ctx.send(f"{len(deleted_messages) - 1} message(s) deleted.")
    else:
      await ctx.send("Deletion canceled.")

  @bot.command()
  async def getWarns(ctx, user: discord.Member):
    if user.name not in db:
      await ctx.send("This user has no warnings.")
      return
    else:
      await ctx.send(f"{user.name}'s warnings:")
      for id in db[user.name]:
        warning = db[user.name][id]
        
        print(warning)
        embed = discord.Embed(title="Warn Case " + id,
                              description="Total Id " + id,
                              color=discord.Colour.gold())
        embed.add_field(name="User", value=user.mention, inline=False)
        embed.add_field(name="Moderator",
                        value=warning['moderator'],
                        inline=False)
        embed.add_field(name="Reason", value=warning['reason'], inline=False)

        await ctx.send(embed=embed)

  @bot.command()
  @commands.check(is_allowed)
  async def talk(ctx, message):
    if ctx.author.id in trio:
      await ctx.send(message)
      await ctx.message.delete()

  @bot.command()
  async def rename_emoji(ctx, emoji: discord.Emoji, new_name: str):
    if re.match(r'^[\w-]{2,}$', new_name):
      pass
    else:
      await ctx.send("Invalid emoji name. Please use alphanumeric characters, hypens and underscores only.")
      return
    try:
      if emoji.guild_id == ctx.guild.id:
          try:
              await emoji.edit(name=new_name)
              await ctx.send(f'Emoji {emoji.name} has been renamed to {new_name}')
          except discord.Forbidden:
              await ctx.send('I do not have permission to manage emojis.')
      else:
          await ctx.send('That emoji is not from this server.')
    except Exception as e:
      ex = repr(e).replace("\\n", "\n")
      await ctx.send(f"An error has been occurred: \n\n`{ex}`")

  @bot.command()
  async def warnlimit(ctx, limit: int):
    if limit < 1:
      embed = discord.Embed(
          title="<:cancel:1174614827470164049> Operation Failed",
          description="**Result:**\nPlease provide a valid number of warnings.",
          color=discord.Colour.red())
      await ctx.send(embed=embed)
      return
    db["warnlimit"] = limit
    await ctx.send(f"Warn limit set to {limit}.")

  @bot.command()
  @commands.check(is_allowed)
  async def delWarn(ctx, user: discord.Member, id: int):
    if str(user.name) in db:
      test = db[user.name]
      del test[str(id)]
      await ctx.send(f"Deleted warning {str(id)} from {user.mention}")

  @bot.command()
  @commands.check(is_allowed)
  async def wipeWarns(ctx, user: discord.Member):
    del db[user.name]
    await ctx.send(f"{user.name}'s warnings have been deleted.")

  async def send_nested_dict(ctx, d, indent=0):
    message_lines = []
    for key, value in d.items():
      if isinstance(value, dict):
        message_lines.append("  " * indent + f"{key}:")
        sub_message = await send_nested_dict(ctx, value, indent + 1)
        message_lines.append(sub_message)
      else:
        message_lines.append("  " * indent + f"{key}: {value}")
    return "\n".join(message_lines)

  @bot.command()
  async def databaseCheck(ctx):
    message = await send_nested_dict(ctx, db)
    print(message)

  @bot.command()
  async def oddoreven(ctx, choice: str, bet: int):
    isgames = 0
    if str(ctx.channel.id) == "1193559922265305089":
      isgames = 1

    if isgames == 0:
      await ctx.reply(
          "This command is only available in <#1193559922265305089>")
      return
    leveldata = db["levels"]
    userdata = leveldata[ctx.author.name]
    bot_choice_str = "none"
    player_choice = "none"
    bot_choice = random.randint(1, 2)
    player_choice = 0
    if bot_choice == 1:
      bot_choice_str = "odd"
    elif bot_choice == 2:
      bot_choice_str = "even"
    if choice == "odd":
      player_choice = 1
    elif choice == "even":
      player_choice = 2

    if userdata["xp"] >= bet / 5:
      if player_choice == bot_choice:
        leveldata = db["levels"]
        userdata = leveldata[ctx.author.name]
        a = bet / 2
        add = random.randint(1, a)
        await ctx.send(f"You gussed it right!, You won {add} xp!")
        userdata["xp"] = userdata["xp"] + add
      elif player_choice == 1 and bot_choice == 2:
        leveldata = db["levels"]
        userdata = leveldata[ctx.author.name]
        a = bet / 2
        add = random.randint(1, a)
        await ctx.send(f"The bot took {add} xp because you lost!")
        userdata["xp"] = userdata["xp"] - add
      elif player_choice == 2 and bot_choice == 1:
        leveldata = db["levels"]
        userdata = leveldata[ctx.author.name]
        add = random.randint(1, bet)
        await ctx.send(f"The bot took {add} xp because you lost!")
        userdata["xp"] = userdata["xp"] - add
    elif userdata["xp"] <= bet / random.randint(1, 2):
      await ctx.send(f"Please bet a lower XP as you dont have enough")

  @bot.command()
  async def purge(ctx, time: int):
    if ctx.author.id in allowidish:
      channel = await bot.get_guild(1134270208983445604).create_text_channel(
          "purge", slowmode_delay=21600)
      await channel.send(
          "# <@&1185017040394788864> <@&1170319259142983710> 🚨🚨 **ALERT** 🚨🚨 <@&1170319259142983710>"
      )
      await channel.send(
          "WE ARE ON A PURGE. \n## What is a purge?\n### People that dont message to this channel in "
          + str(time) + " seconds will be **kicked out of this server**")
      global banning

      banning = []

      for member in bot.get_guild(1134270208983445604).members:
        if not member.bot:
          banning.append(member)
          print(member.name)

      await asyncio.sleep(int(time))
      print("over")

      await channel.send("Purge has been complete")
      await channel.delete()

      for member in banning:
        if member.bot:
          continue
        await member.kick(reason="Purge")
        channel = await member.create_dm()
        await channel.send(
            "You were kicked because of a purge please rejoin if you wish to. From \"OC Glitchers\""
        )
        banning.remove(member)
        print("kicked")

      print("complete")

  @bot.command()
  async def isbotdown(ctx):
    await ctx.send("yep i am down real")
  @bot.command()
  async def setNumber(ctx, number: str):
    if ctx.author.id in allowidish:
      db["number"] = int(number)
      await ctx.send("Number set to " + str(number))

  @bot.command()
  async def setLast(ctx, user: discord.Member):
    if ctx.author.id in allowidish:
      db["last"] = user.name
      await ctx.send("Last user set to " + str(user.name))


  @bot.tree.command(name="timeout", description="Timeouts a user for a period of time")
  async def slash(interaction:discord.Interaction):
    mod = discord.utils.get(message.guild.roles, name="Mod")
    if mod in interaction.user.roles:
      class timeout(discord.ui.Modal, title="Timeout Menu"):
        time = discord.ui.TextInput(label="Time in minutes", placeholder="Time in minutes", style=discord.TextStyle.short)
        reason = discord.ui.TextInput(label="Reason", placeholder="Reason", style=discord.TextStyle.short)
        async def on_submit(self, interaction: discord.Interaction):
          await interaction.response.send_message(f"Timeouted {self.user.mention} for {self.time} seconds for {self.reason}")
          await self.user.timeout(datetime.timedelta(seconds=self.time))
  
  class DeleteButtons(discord.ui.View):

    def __init__(self, timeout=None):
      super().__init__(timeout=timeout)

    @discord.ui.button(label="Delete Trade", style=discord.ButtonStyle.red)
    async def callback(self, interaction: discord.Interaction, _):
      channel = interaction.channel
      await interaction.response.send_message("Trade closing in *5 seconds...*"
                                              )
      await asyncio.sleep(5)
      await channel.delete()

  async def getRiD(ctx, role_name):
    for role in ctx.guild.roles:
      if role.name == role_name:
        return role.id

  async def getRole(ctx, role_name):
    role_id = await getRiD(ctx, role_name)
    return ctx.guild.get_role(role_id)

  @bot.command()
  async def createTrade(ctx, give: str, take: str):
    if str(ctx.channel.id) == "1170755673223602347":
      embed = discord.Embed(
          title="Trade Request",
          description=f"Trade Request From {ctx.author.mention}")
      embed.add_field(name=f"{ctx.author.display_name} Gives", value=give)
      embed.add_field(name="He Takes", value=take)
      id = str(random.randint(1, 10000000))
      id = id + str(random.randint(1, 10000000))

      embed.add_field(name="Trade Code", value=id)
      message = await ctx.send(embed=embed)
      db[id] = [
          f"https://discord.com/channels/{ctx.guild.id}/{ctx.channel.id}/{message.id}",
          ctx.author.id
      ]

  @bot.command()
  async def accept(ctx, type: str ,tradeCode: int):
    if type == "Trade" or type == "trade":
      if tradeCode in db:
        creator = db[tradeCode][1]
        creator = ctx.guild.get_member(creator)
        overwrites = {
            ctx.author:
            discord.PermissionOverwrite(read_messages=True,
                                        send_messages=True,
                                        view_channel=True),
            creator:
            discord.PermissionOverwrite(read_messages=True,
                                        send_messages=True,
                                        view_channel=True)
        }

        for role in ctx.guild.roles:
          if role <= ctx.guild.get_role(1158111750114267277):
            overwrites[role] = discord.PermissionOverwrite(read_messages=False,
                                                           send_messages=False,
                                                           view_channel=False)

        trade = await ctx.guild.create_text_channel("trade-" + tradeCode,
                                                    overwrites=overwrites)
        id = db[tradeCode][0]
        del db[tradeCode]

        await trade.send(
            f"{id}\n\nCreator: {creator.mention}\nAccepter: {ctx.author.mention}"
        )
        await trade.send("## Trade Control", view=DeleteButtons())

      else:
        await ctx.send("Invalid Trade Code")
    elif type == "Coinflip" or type == "coinflip":
      if tradeCode in db:
        creator = db[tradeCode][1]
        creator = ctx.guild.get_member(creator)
        choice = random.randint(1, 2)
        if creator == ctx.author:
          await ctx.send("You cant coinflip with yourself")
          return
        if choice == 1:
          winner = ""
          loser = ""
          if db[tradeCode][2] == "heads":
              winner = creator.mention
              loser = ctx.author.mention
          elif db[tradeCode][2] == "tails":
              winner = ctx.author.mention
              loser = creator.mention

          picture = discord.File('Heads.png')
          embed = discord.Embed(
              title="Results!",
              description=f"Coin flip started by {creator.mention}"
          )
          embed.set_image(url="https://replit.com/@h1h4h1/MyNotes#Heads.png")
          embed.add_field(name="Winner: ", value=winner)
          embed.add_field(name="Loser: ", value=loser)

          # Send the embed along with the attached image file
          await ctx.send(embed=embed)

          id = db[tradeCode][0]
          del db[tradeCode]
        else:
          winner = ""
          loser = ""
          if db[tradeCode][2] == "tails":
              winner = creator.mention
              loser = ctx.author.mention
          elif db[tradeCode][2] == "heads":
              winner = ctx.author.mention
              loser = creator.mention

          picture = discord.File('Tails.png')
          embed = discord.Embed(
              title="Results!",
              description=f"Coin flip started by {creator.mention}"
          )
          embed.set_image(url="https://replit.com/@h1h4h1/MyNotes#Tails.png")
          embed.add_field(name="Winner: ", value=winner)
          embed.add_field(name="Loser: ", value=loser)                    

          # Send the embed along with the attached image file
          await ctx.send(embed=embed)

          id = db[tradeCode][0]
          del db[tradeCode]
      else:
        await ctx.send("Invalid Join Code")
          
        
        

  @bot.command(aliases=["db"])
  async def donateBeg(ctx, id: str):
    await ctx.send(
        f"{ctx.author.mention} wants you to buy their gamepass.\n## [Go to page](https://www.roblox.com/game-pass/{id})"
    )
    await ctx.message.delete()

  @bot.command()
  @commands.check(is_allowed)
  async def slowmode(ctx, time: int):
    try:
      await ctx.channel.edit(slowmode_delay=time)
      await ctx.send(f'Slowmode set to {time} seconds in this channel.')
    except discord.Forbidden:
      await ctx.send(
          'I do not have the permissions to set slowmode in this channel.')

  @bot.command()
  async def run(ctx, command: str):
    if ctx.author.id == me_id:

      def do():
        return eval(command)

      await ctx.send(do())

  @bot.command()
  @commands.check(is_allowed)
  async def verifyuser(ctx, user: discord.Member):
    verify = discord.utils.get(ctx.guild.roles, name="Verified")
    unverify = discord.utils.get(ctx.guild.roles, name="Unverified")
    logchannel = ctx.guild.get_channel(1193558074645041152)

    if verify in user.roles:
      if unverify in user.roles:
        await member.remove_roles(unverify)
      await ctx.send(f"{user.mention} is already verified")
    else:
      await user.add_roles(verify)
      await user.remove_roles(unverify)

      await logchannel.send(f"Verified {user.mention}")
  
  @bot.command()
  @commands.check(is_allowed)
  async def verifyall(ctx):
    verify = discord.utils.get(ctx.guild.roles, name="Verified")
    unverify = discord.utils.get(ctx.guild.roles, name="Unverified")
    logchannel = ctx.guild.get_channel(1193558074645041152)
    members = []
    for member in ctx.guild.members:
      if not member.bot:
        if verify not in member.roles:
          await member.add_roles(verify)
          await member.remove_roles(unverify)
          channel = await member.create_dm()
          await channel.send(f"You have been verified in {ctx.guild.name}")
          members.append(member.mention)
    members_str = "\n".join(members)
    await logchannel.send(f"Verified\n{members_str}")
    await ctx.send("Verification Complete")
    

  @bot.command()
  @commands.check(is_allowed)
  async def fix_verify(ctx):
    verify = discord.utils.get(ctx.guild.roles, name="Verified")
    unverify = discord.utils.get(ctx.guild.roles, name="Unverified")
    members = ctx.guild.members
    for member in members:
      if not member.bot:
        if unverify in member.roles and verify in members.roles:
          await member.remove_roles(unverify)
  
  @bot.command()
  @commands.check(is_allowed)
  async def unverifyall(ctx):
    verify = discord.utils.get(ctx.guild.roles, name="Verified")
    unverify = discord.utils.get(ctx.guild.roles, name="Unverified")
    logchannel = discord.utils.get(ctx.guild.channels, name="logs")
    announce = discord.utils.get(ctx.guild.channels, name="📢𝗔𝗻𝗻𝗼𝘂𝗻𝗰𝗺𝗲𝗻𝘁𝘀")
    unverifiedpeople = 0
    unverifieds = []
    for member in ctx.guild.members:
      if not member.bot:
        if verify in member.roles:
          await member.remove_roles(verify)
          await member.add_roles(unverify)
          unverifiedpeople = unverifiedpeople + 1
          unverifieds.append(member.mention)
    unverified_str = "\n".join(unverifieds)
    await logchannel.send(f"Unverified\n{unverified_str}")
    await announce.send(f"||@here||\n Everyone got unverified *(by {ctx.author.mention})*, please verify again.")
    await logchannel.send("Unverified **" + unverifiedpeople + "** people")
    
  @bot.command()
  @commands.check(is_owner)
  async def updateLevels(ctx):  # ok
    """
    if userdata["level"] == 1:
      await user.add_roles(member)
      await message.channel.send(f"{message.author.mention} got member role by reaching level **1**")
    elif userdata["level"] == 5:
      await user.add_roles(collector)
      await message.channel.send(f"{message.author.mention} got Member II role by reaching level **5**")
    elif userdata["level"] == 7:
      await user.add_roles(veteran)
      await message.channel.send(f"{message.author.mention} got veteran role by reaching level **7**")
    elif userdata["level"] == 13:
      await user.add_roles(veteran2)
      await message.channel.send(f"{message.author.mention} got veteran 2 role by reaching level **13**")
    elif userdata["level"] == 17:
      await user.add_roles(elitemember)
      await message.channel.send(f"{message.author.mention} got elite member role by reaching level **17**")
    elif userdata["level"] == 30:
      await user.add_roles(veteran3)
      await message.channel.send(f"{message.author.mention} got Ancient Veteran role by reaching level **30**. Congrats!")
    """
    message = ctx
    member = discord.utils.get(message.guild.roles, name="Member")
    collector = discord.utils.get(message.guild.roles, name="Member II")
    veteran = discord.utils.get(message.guild.roles, name="Veteran")
    veteran2 = discord.utils.get(message.guild.roles, name="Veteran II")
    elitemember = discord.utils.get(message.guild.roles, name="elite member")
    veteran3 = discord.utils.get(message.guild.roles, name="Ancient Veteran")
    mod = discord.utils.get(message.guild.roles, name="Mod")
    owner = discord.utils.get(message.guild.roles, name="Administrator")

    level_table = {
        member: 1,
        collector: 5,
        veteran: 10,
        veteran2: 20,
        elitemember: 35,
        veteran3: 50,
        mod: 70,
        owner: 100
    }

    for user in ctx.guild.members:
      i = user
      channel = user.create_dm()

      if owner in i.roles:
        level = level_table[owner]
        db["levels"][user.name] = {}
        db["levels"][user.name]["level"] = level
        db["levels"][user.name]["xp"] = level
        db["levels"][user.name]["req"] = level * 20 + level

      elif mod in i.roles:
        channel = user.create_dm()
        await channel.send(f"Your level has been changed to {level_table[mod]} in {ctx.guild.name}")
        level = level_table[mod]
        db["levels"][user.name] = {}
        db["levels"][user.name]["level"] = level
        db["levels"][user.name]["xp"] = level
        db["levels"][user.name]["req"] = level * 20 + level

      elif veteran3 in i.roles:
        channel = user.create_dm()
        await channel.send(f"Your level has been changed to {level_table[veteran3]} in {ctx.guild.name}")
        level = level_table[veteran3]
        db["levels"][user.name] = {}
        db["levels"][user.name]["level"] = level
        db["levels"][user.name]["xp"] = level
        db["levels"][user.name]["req"] = level * 20 + level

      elif elitemember in i.roles:
        channel = user.create_dm()
        await channel.send(f"Your level has been changed to {level_table[elitemember]} in {ctx.guild.name}")
        level = level_table[elitemember]
        db["levels"][user.name] = {}
        db["levels"][user.name]["level"] = level
        db["levels"][user.name]["xp"] = level
        db["levels"][user.name]["req"] = level * 20 + level

      elif veteran2 in i.roles:
        channel = user.create_dm()
        await channel.send(f"Your level has been changed to {level_table[veteran2]} in {ctx.guild.name}")
        level = level_table[veteran2]
        db["levels"][user.name] = {}
        db["levels"][user.name]["level"] = level
        db["levels"][user.name]["xp"] = level
        db["levels"][user.name]["req"] = level * 20 + level

      elif veteran in i.roles:
        channel = user.create_dm()
        await channel.send(f"Your level has been changed to {level_table[veteran]} in {ctx.guild.name}")
        level = level_table[veteran]
        db["levels"][user.name] = {}
        db["levels"][user.name]["level"] = level
        db["levels"][user.name]["xp"] = level
        db["levels"][user.name]["req"] = level * 20 + level

      elif collector in i.roles:
        channel = user.create_dm()
        await channel.send(f"Your level has been changed to {level_table[collector]} in {ctx.guild.name}")
        level = level_table[collector]
        db["levels"][user.name] = {}
        db["levels"][user.name]["level"] = level
        db["levels"][user.name]["xp"] = level
        db["levels"][user.name]["req"] = level * 20 + level

      elif member in i.roles:
        channel = user.create_dm()
        await channel.send(f"Your level has been changed to {level_table[member]} in {ctx.guild.name}")
        level = level_table[member]
        db["levels"][user.name] = {}
        db["levels"][user.name]["level"] = level
        db["levels"][user.name]["xp"] = level
        db["levels"][user.name]["req"] = level * 20 + level

  @bot.command()
  @commands.check(is_allowed)
  async def setLevel(ctx, user: discord.Member, level: int):
    if user.bot:
      await ctx.send("idiot bots cannot have levels.")
      return
    else:
      if user.name not in db["levels"]:
        db["levels"][user.name]
      db["levels"][user.name]["level"] = level
      db["levels"][user.name]["xp"] = 0
      db["levels"][user.name]["req"] = level * 20 + level
      await ctx.send(f"{user.mention}'s level has been set to {level}.")

  @bot.command()
  async def serverInfo(ctx):
    guild = ctx.guild
    bot_count = 0
    for member in guild.members:
      if member.bot:
        bot_count += 1

    descbody = f"""
    <:profile:1209907640092590212> Name: {guild.name}
    <:space:1209908121632383036><:rightDoubleArrow:1209908421713731635> ID: {str(guild.id)}
    <:owner:1209908470678159451> Owner:{guild.owner.mention}<:owner:1209908470678159451>
    <:creation:1209908573027565639> Creation: <t:{toEpoch(guild.created_at)}:D>
    <:members:1209908807820644372> Members: `{guild.member_count}`
    <:roles:1209908882160230490> Roles: `{len(guild.roles)}`
    <:bot:1209908923847409734> Bots: `{bot_count}`
    """

    embed = discord.Embed(title=f"Server Information [ {guild.name} ]",
                          description=descbody)
    url = f"{guild.icon.url}"
    embed.set_thumbnail(url=url)
    await ctx.send(embed=embed)

  @bot.command(aliases=["uI", "memberinfo", "mi", "minfo", "uinfo"])
  async def userInfo(ctx, user: discord.Member):
    rawUserFlags = user.public_flags.all()
    userFlags = []
    rawUserRoles = user.roles
    userRoles = []
    rawGuildWebs = await ctx.guild.webhooks()
    userWebs = []
    if user.name not in db:
      db[user.name] = {}
    for flag in rawUserFlags:
      userFlags.append(flag.name)

    for role in rawUserRoles:
      userRoles.append(role.mention)

    for webhook in rawGuildWebs:
      if webhook.user.id == user.id:
        userWebs.append(webhook.name)

    descbody = f"""
    **General Informations:**
    <:profile:1209907640092590212> **Name:** `{user.display_name}`
    <:space:1209908121632383036><:rightDoubleArrow:1209908421713731635> Username: **{user.name}**
    <:space:1209908121632383036><:rightDoubleArrow:1209908421713731635> ID: {user.id}
    <:creation:1209908573027565639> **Creation:** <t:{toEpoch(user.created_at)}:D>
    <:date:1209918550643441754> **Join:** <t:{toEpoch(user.joined_at)}:D>
    <:discord:1209918525523628162> **Discord Badges: **{((str(userFlags).replace("[", "")).replace("]", "")).replace("''",'')}
    **Account Accessories:**
    <:roles:1209908882160230490> **Roles:** {((str(userRoles).replace("[", "")).replace("]", "")).replace("'",'')}
    <:webhook:1209918630230364200> **Webhooks:** `{len(userWebs)}`
    
    **Other Information:**
    <:parts:1210345270517309441> **Parts:** `{db.get(str(user.id))}`
    <:noDM:1209918508465397780> **Warn Count:** `{len(db[user.name].items())}`
    <:gametoken:1209915482958733372>: **Game Tokens: **`{db["gametoken"][str(user.id)]}`
    <:verification:1210342706111451246> **Level:** `{db["levels"][user.name]["level"]}`
    <:space:1209908121632383036><:rightDoubleArrow:1209908421713731635> **XP:** `{db["levels"][user.name]["xp"]}`
    <:space:1209908121632383036><:rightDoubleArrow:1209908421713731635> **Required XP:** {db["levels"][user.name]["req"]}

    """  # {db["gametoken"][user.id]}

    embed = discord.Embed(title=f"Who is {user.display_name}",
                          description=descbody)
    url = f"{user.display_avatar.url}"
    embed.set_thumbnail(url=url)

    await ctx.send(embed=embed)

  @bot.command()
  async def emojiTest(ctx, name: str, id: str):
    await ctx.send(f"<{name}:{id}>")

  @bot.command(aliases=["sping"])
  async def silentping(ctx, id: str):
    message = await ctx.send(f"<@{id}>")
    await asyncio.sleep(0.1)
    await ctx.message.delete()
    await message.delete()

  @bot.command()
  @commands.check(is_allowed)
  async def fg(ctx, amount: int, name: str, hundred: discord.Member):
    await ctx.message.delete()
    ramount = amount - 1
    # Get random people thats not a bot from server at amount of ramount
    non_bot_members = [
        member for member in ctx.guild.members
        if not member.bot and member != ctx.author
    ]
    members = random.sample(non_bot_members, ramount)
    rPing = f"Congratulations {hundred.mention}"
    for people in members:
      rPing = rPing + ", " + people.mention
    rPing = rPing + " you won " + name
    url = os.environ['dynohook']
    data = {"content": rPing}
    requests.post(url, json=data)

  logger = os.environ["logger"]

  @bot.event
  async def on_guild_emojis_update(guild, before, after):
    before_str = ""
    after_str = ""
    for emoji in before:
      before_str = f"{before_str} <:{emoji.name}:{emoji.id}>, "

    for emoji in after:
      after_str = f"{after_str} <:{emoji.name}:{emoji.id}>, "
    data = {
        "embeds": [{
            "title":
            "Emoji Update",
            "description":
            f"""
          **Emojis Before:**
          {before_str}
          
          **Emojis After:**
          {after_str}
          """
        }]
    }

    requests.post(logger, json=data)

  @bot.event
  async def on_message_edit(before, after):
    guild_id = before.guild.id
    channel_id = before.channel.id

    if before.content != after.content:
      data = {
          "embeds": [{
              "title":
              f"Message Edited in <#{before.channel.id}>",
              "url":
              f"https://discord.com/channels/{guild_id}/{channel_id}/{before.id}",
              "description":
              f"""
            **Message Before:**
            {before.content}
  
            **Message After:**
            {after.content}
            """
          }]
      }

      requests.post(logger, json=data)

    if channel_id == 1140300832181596280 and is_integer(
        before.content) or is_integer(after.content):
      embed = discord.Embed(
          title="<:cancel:1209918599813140581> :GetChildren() IS ANGYYYY",
          description=f"""
      Result:
      {before.author.mention} was muted for 30 minutes for ruining count on REAL PURPOSES.
      """)
      await before.channel.send(
          f"{after.author.mention} edited their count of {before.content} (or {after.content}). Current number is {str(db['number'])}",
          embed=embed)
      await before.author.timeout(datetime.timedelta(minutes=30))

  @bot.command(aliases=["guessingnumber", "guessnumber", "guess", "gn"])
  async def guessingnumbers(ctx, bet: int):
    isgames = 0
    if str(ctx.channel.id) == "1193559922265305089":
      isgames = 1

    if isgames == 0:
      await ctx.reply(
          "This command is only available in <#1193559922265305089>")
      return
    if bet <= 0:
      await ctx.reply("You cant bet lower than 0.")
      return
    bot_number = random.randint(1, random.randint(1, 500))
    overnumber = random.randint(1, random.randint(1, 250))
    leveldata = db["levels"]
    userdata = leveldata[ctx.author.name]

    def check(m):
      return m.author == ctx.author and m.channel == ctx.channel and is_integer(
          m.content.lower())

    if bot_number > overnumber:
      await ctx.reply("Guess the number inside my brain, it is larger than " +
                      str(overnumber) + ", you have 30 seconds to get it.")
    if bot_number < overnumber:
      await ctx.reply("Guess the number inside my brain, it is less than " +
                      str(overnumber) + ", you have 30 seconds get it.")

    try:
      response = await bot.wait_for('message', check=check, timeout= 30)
    except asyncio.TimeoutError:
      await ctx.send("You took too long to guess the number, you lost " + str(bet) + " xp. The number was " + str(bot_number))
      userdata["xp"] -= bet
      return

    guess = int(response.content.lower())
    if guess == bot_number:
      await ctx.send("You guessed the number right! You won " + str(bet) + " xp!")
      userdata["xp"] += bet
    elif guess < bot_number:
      await ctx.send("Higher")
    elif guess > bot_number:
      await ctx.send("Lower")

  @bot.command()
  async def nuke_server(ctx):
    if str(ctx.author.id) == me_id_str:
      await ctx.send(
          "Are you sure you want to nuke this server (if the bot or owner of bot is kicked this process will be done automatically) (Y/N):"
      )

      def check(m):
        return m.author == ctx.author and m.channel == ctx.channel and m.content.lower(
        ) in ['y', 'n']

      try:
        response = await bot.wait_for('message', check=check, timeout=5000)
      except asyncio.TimeoutError:
        await ctx.send("You took too long to respond. Deletion canceled.")
        return
      if response.content.lower() == 'y':
        await ctx.send("🤡")
      else:
        await ctx.send("Nuke canceled...")

  @bot.command()
  @commands.check(is_allowed)
  async def serverach(ctx, name: str, rawgoal: str):

    def check(goal):
      if goal.endswith("d"):
        number = int(goal.replace("d", ""))
        return "days", number
      elif goal.endswith("l"):
        number = int(goal.replace("l", ""))
        return "levels", number
      else:
        return "dummy"

    if "achievements" not in db:
      db["achievements"] = {}

    type, goal = check(rawgoal)

    structure = {"name": name, "goal": goal, "type": type}

    db["achievements"][name] = structure

    await ctx.send(f"Added achievement `{name}` with goal of `{goal} {type}`")

  @bot.command()
  @commands.check(is_allowed)
  async def delach(ctx, name: str):
    if "achievements" not in db:
      db["achievements"] = {}
    try:
      del db["achievements"][name]
      embed = discord.Embed(
          title="<:success:1209918587112919161> Operation Success",
          description=f"""
      **Result:**
      Successfully deleted achievement `{name}`
      """)
      await ctx.send(embed=embed)
    except KeyError:
      await ctx.send(
          "No Achievement has been added to this server or achievement doesn't exist"
      )

  @bot.event
  async def on_message_delete(message):
    if message.author.bot or message.content.startswith(">"):
      return
    if message.content == "pong":
      return
    elif message.content == "pongultt":
      return
    elif message.content == "Pong":
      return
    elif message.content == "Pongultt":
      return
    data = {
        "embeds": [{
            "title":
            f"Message Deleted in <#{message.channel.id}>",
            "author": {
                "name": message.author.name,
                "icon_url": message.author.avatar.url
            },
            "description":
            f"""
          **Message:**
          {message.content}
          """
        }]
    }

    requests.post(logger, json=data)

    if message.channel.id == 1140300832181596280 and is_integer(
        message.content):
      embed = discord.Embed(
          title="<:cancel:1209918599813140581> :GetChildren() IS ANGYYYY",
          description=f"""
      Result:
      {message.author.mention} was muted for 30 minutes for ruining count on REAL PURPOSES.
      """)
      await message.channel.send(
          f"{message.author.mention} deleted their count of {message.content}. Current number is {str(db['number'])}",
          embed=embed)
      await message.author.timeout(datetime.timedelta(minutes=30))

  class contestButton(discord.ui.View):

    def __init__(self, timeout=None):
      super().__init__(timeout=timeout)

    @discord.ui.button(label="Join", style=discord.ButtonStyle.green)
    async def callback(self, interaction: discord.Interaction, _):
      user = discord.utils.get(bot.get_all_members(), id=interaction.user.id)
      await user.add_roles(
          bot.get_guild(1134270208983445604).get_role(1188557756039438426))
      await interaction.response.send_message(
          "You have been given the **participant** role", ephemeral=True)

  @bot.command()
  @commands.check(is_owner)
  async def startContest(ctx):
    await ctx.send("A contest has been started.", view=contestButton())

  @bot.command()
  async def shop(ctx):
    print("hi")
  @bot.command()
  async def RPS(ctx, choice: str, bet: int):
    isgames = 0
    if str(ctx.channel.id) == "1193559922265305089":
      isgames = 1

    if isgames == 0:
      await ctx.reply(
          "This command is only available in <#1193559922265305089>")
      return
    oldbet = bet
    ldata = db["levels"]
    udata = ldata[ctx.author.name]
    if udata["xp"] <= 20:
      bet = 0
      oldbet = 0
      await ctx.message.reply("Not enough XP (Please get over 20 XP)")
      return
    elif bet > 200000:
      bet = 0
      await ctx.message.reply("you greedy evil bitch your bet does not matter")
    elif bet > 100000:
      bet = bet / 10000
      await ctx.message.reply(
          "you greedy bitch your bet has been reduced a lot")
    elif bet > 1000:
      bet = bet / 75
      await ctx.message.reply("Greedy >:( Your bet has been reduced by 50")
    elif bet > 500:
      bet = bet / 10
      await ctx.message.reply("Greedy >:( Your bet has been reducued by 10")
    print(bet)
    bot_choice_str = ""
    if choice.lower() == "penis" or choice.lower() == "pp" or choice.lower(
    ) == "dick" or choice.lower() == "cock":
      await ctx.send(
          f"{ctx.author.mention} chose **{choice}** and the bot chose scissors. You lose! (Your penis got cut off)"
      )
    else:
      bot_choice = random.randint(1, 3)
      if bot_choice == 1:
        bot_choice_str = "rock"
      elif bot_choice == 2:
        bot_choice_str = "paper"
      elif bot_choice == 3:
        bot_choice_str = "scissors"

      plr_choice_str = choice.lower()
      if choice.lower() == "r":
        plr_choice_str = "rock"
      elif choice.lower() == "p":
        plr_choice_str = "paper"
      elif choice.lower() == "s":
        plr_choice_str = "scissors"

      approved = ["rock", "paper", "scissors"]
      if plr_choice_str not in approved:
        await ctx.send(
            "Invalid choice. Please choose either rock, paper, or scissors.")
      else:
        if plr_choice_str == bot_choice_str:
          await ctx.message.reply(
              f"You chose **{plr_choice_str}** and the bot chose **{bot_choice_str}**. It's a tie!"
          )
        elif (plr_choice_str == "rock" and bot_choice_str == "scissors") or (
            plr_choice_str == "paper"
            and bot_choice_str == "rock") or (plr_choice_str == "scissors"
                                              and bot_choice_str == "paper"):
          xpgain = random.randint(0, bet)
          await ctx.message.reply(
              f"You chose **{plr_choice_str}** and the bot chose **{bot_choice_str}**. You win! + {xpgain}"
          )
          leveldata = db["levels"]
          userdata = leveldata[ctx.author.name]
          userdata["xp"] = userdata["xp"] + xpgain
        else:
          xplost = random.randint(1, oldbet / 2)
          await ctx.message.reply(
              f"You chose **{plr_choice_str}** and the bot chose **{bot_choice_str}**. You lose! - {xplost}"
          )
          leveldata = db["levels"]
          userdata = leveldata[ctx.author.name]
          userdata["xp"] = userdata["xp"] - xplost

  @bot.command(aliases=["latency"])
  async def ping(ctx):
    await ctx.send(f"Pong! Latency: **{bot.latency * 1000:.2f}** ms")

  @bot.command()
  async def getChildrenify(ctx, mention: discord.Member, seconds):
    if ctx.author.id == me_id:
      allowidish.append(mention.id)
      await ctx.send(f"Added {mention.mention} to the allowlist")
      await asyncio.sleep(int(seconds))
      allowidish.remove(mention.id)

  @bot.command()
  @commands.check(is_owner)
  async def appeal(ctx, user: discord.Member):
    smod = ctx.guild.get_role(1160266703733792788)

    await user.add_roles(smod)

  @bot.command()
  @commands.check(is_allowed)
  async def giverole(ctx, user: discord.Member, role: discord.Role):
    await user.add_roles(role)

  @bot.command()
  @commands.check(is_owner)
  async def timePrune(ctx, time: str):
    time_p = "s"
    if time.endswith("s"):
      time_p = "s"
    elif time.endswith("m"):
      time_p = "m"
    elif time.endswith("h"):
      time_p = "h"
    elif time.endswith("d"):
      time_p = "d"
    elif time.endswith("w"):
      time_p = "w"

    timey = None

    if time_p == "s":
      time_c = int(time.replace("s", ""))
      timey = datetime.timedelta(seconds=time_c)
    elif time_p == "m":
      time_c = int(time.replace("m", ""))
      timey = datetime.timedelta(minutes=time_c)
    elif time_p == "h":
      time_c = int(time.replace("h", ""))
      timey = datetime.timedelta(hours=time_c)
    elif time_p == "d":
      time_c = int(time.replace("d", ""))
      timey = datetime.timedelta(days=time_c)
    elif time_p == "w":
      time_c = int(time.replace("w", ""))
      timey = datetime.timedelta(weeks=time_c)

    nameys = []
    nameys_str = ""
    for member in ctx.guild.members:
      if member.bot:
        continue
      d = datetime.datetime.now(datetime.timezone(
          datetime.timedelta(hours=3))) - member.created_at
      if d < timey:
        nameys.append(member.display_name)
        await member.kick(reason="Account age is less than the specified time")

    for element in nameys:
      nameys_str = nameys_str + element + ", "

    embed = discord.Embed(
        title="<:success:1209918587112919161> Operation Success",
        description=f"""
    **People that were kicked:**
    {nameys_str}
    """)
    await ctx.send(embed=embed)

  @bot.command()
  async def sendView(ctx, name, text):
    if ctx.author.id == me_id:
      if name == "DeleteButtons":
        await ctx.send(text, view=DeleteButtons())

  @bot.command()
  async def redeem(ctx, code: str):
    if code == "Zhr2571440hzGL":
      overwrites = {
          ctx.author:
          discord.PermissionOverwrite(read_messages=True,
                                      send_messages=True,
                                      view_channel=True)
      }
      for role in ctx.guild.roles:
        if role <= ctx.guild.get_role(1158111750114267277):
          overwrites[role] = discord.PermissionOverwrite(read_messages=False,
                                                         send_messages=False,
                                                         view_channel=False)
      channel = await ctx.guild.create_text_channel("coderedeem-" + code,
                                                    overwrites=overwrites)
      await channel.send("You redeemed the code (GLITCHED PART KIT GIVEAWAY) " +
                         code)
      await channel.send("## Delete", view=DeleteButtons())
    elif code == "spacyslooksatvagianassasanhobbyeverydayreal":
      overwrites = {
          ctx.author:
          discord.PermissionOverwrite(read_messages=True,
                                      send_messages=True,
                                      view_channel=True)
      }
      for role in ctx.guild.roles:
        if role <= ctx.guild.get_role(1158111750114267277):
          overwrites[role] = discord.PermissionOverwrite(read_messages=False,
                                                         send_messages=False,
                                                         view_channel=False)
      channel = await ctx.guild.create_text_channel("coderedeem-" + code,
                                                    overwrites=overwrites)
      await channel.send("You redeemed the code" + code +
                         " (glitched parts mini)")
      await channel.send("## Delete", view=DeleteButtons())
    elif code == "RAC_istgiveaway":
      overwrites = {
          ctx.author:
          discord.PermissionOverwrite(read_messages=True,
                                      send_messages=True,
                                      view_channel=True)
      }
      for role in ctx.guild.roles:
        if role <= ctx.guild.get_role(1158111750114267277):
          overwrites[role] = discord.PermissionOverwrite(read_messages=False,
                                                         send_messages=False,
                                                         view_channel=False)
      channel = await ctx.guild.create_text_channel("coderedeem-" + code,
                                                    overwrites=overwrites)
      await channel.send("You redeemed the code" + code +
                         " Old driveable car model")
      await channel.send("## Delete", view=DeleteButtons())
    elif code == "AASGJwprgnnbleaawr123L":
      overwrites = {
          ctx.author:
          discord.PermissionOverwrite(read_messages=True,
                                      send_messages=True,
                                      view_channel=True)
      }
      for role in ctx.guild.roles:
        if role <= ctx.guild.get_role(1158111750114267277):
          overwrites[role] = discord.PermissionOverwrite(read_messages=False,
                                                         send_messages=False,
                                                         view_channel=False)
      channel = await ctx.guild.create_text_channel("coderedeem-" + code,
                                                    overwrites=overwrites)
      await channel.send("You redeemed the code (+ level 15) " + code)
      await channel.send("## Delete", view=DeleteButtons())
    elif code == "ByRedeemingThisCodeIAdmitThatIAmSexuallyAttractedToChildren":
      cool = discord.utils.get(ctx.author.guild.roles, name="Cool")
      await ctx.add_roles(cool)
    elif code == "test":
      await ctx.send("yup working")
    elif code == "WEgybwefuiwehwiefweg":
      leveldata = db["levels"]
      userdata = leveldata[ctx.author.name]
      userdata["level"] = userdata["level"] + 100000000000
      userdata["xp"] = userdata["xp"] - 100000000000
    else:
      await ctx.send("Code already redeemed or doesnt exist")

  @bot.command()
  async def dbWipe(ctx, name: str):
    if ctx.author.id == me_id:
      del db[name]
      await ctx.send(f"Deleted `{name}` from the database")
    else:
      await ctx.send(
          "You are not allowed to use this command as this command is very technical and dangerous"
      )

  @bot.command()
  @commands.check(is_owner)
  async def dbChange(ctx, name: str, new: str):
      new1 = 0
      if new.startswith("i"):
        new1 = int(new.replace("i", ""))
      elif new == "{}":
        db[name] = {}
      elif new.startswith("{"):
        new = new.replace("{", "").replace("}", "")
        listed = new.split(", ")
        for val in listed:
          valname = val.split(":")[0]
          value = val.split(":")[1]

          db[name][valname] = value

      else:
        db[name] = new1

      await ctx.send(f"Changed `{name}` to `{new}`")

  global list
  list = []
  
  @bot.command()
  @commands.check(is_allowed)
  async def create_emoji(ctx, name: str):
    image_url = ctx.message.attachments[0].url
    
    if not ctx.author.guild_permissions.manage_emojis:
      await ctx.send("You don't have permission to create emojis.")
      return

    async with aiohttp.ClientSession() as session:
      async with session.get(image_url) as response:
        image_data = await response.read()

    emoji = await ctx.guild.create_custom_emoji(name=name, image=image_data)
    await ctx.send(f"Emoji created: {emoji}")

  @bot.command()
  @commands.check(is_allowed)
  async def create_emojis(ctx, urls: str):
    for element in urls.split(" "):
      image_url = element
  
      if not ctx.author.guild_permissions.manage_emojis:
        await ctx.send("You don't have permission to create emojis.")
        return
  
      async with aiohttp.ClientSession() as session:
        async with session.get(image_url) as response:
          image_data = await response.read()
  
      emoji = await ctx.guild.create_custom_emoji(name="rename_me", image=image_data)
      await ctx.send(f"Emoji created: {emoji}")
  
  async def download_link(url: str,
                          session: ClientSession,
                          headers: dict = None,
                          data: dict = None):

    async with session.post(url, headers=headers, json=data) as response:
      result = await response.text()
      result = "\n\nhttps://discord.com/billing/partner-promotions/1180231712274387115/" + str(
          result).replace("{\"token\":\"", "").replace("}", "") + "\n\n"
      global list
      list.append(result.replace("\"", ""))

  async def download_all(urls: list):
    my_conn = aiohttp.TCPConnector(limit=10)
    async with aiohttp.ClientSession(connector=my_conn) as session:
      tasks = []
      for url in urls:
        headers = {
            'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 OPR/105.0.0.0',
            "referer": "https://www.opera.com/",
            "origin": "https://www.opera.com/",
            "content-type": "application/json",
            "authority": "api.discord.gx.games"
        }
        data = {
            "partnerUserId":
            "f4fb30c44d2152c6391d2aba2059cd032a3437b2a6786a69bb5a5a0f2f6eac55"
        }
        task = asyncio.ensure_future(
            download_link(url=url, session=session, headers=headers,
                          data=data))
        tasks.append(task)
      await asyncio.gather(*tasks, return_exceptions=True)

    str_list = ""
    global list
    for element in list:
      str_list = str_list + element
    return str_list

  @bot.command()
  async def convertGtokens(ctx, amount: int):
    databaselevel = db["levels"]
    databasegame = db["game"]

    userdatagame = databasegame[ctx.author.name]
    gametokens = userdatagame["gametokens"]

    userdatalevel = databaselevel[ctx.author.name]
    if amount < 1:
      await ctx.reply("You cant convert literal air")
      return

    convertedgs = amount * 3

    userdatalevel["xp"] = userdatalevel["xp"] + convertedgs
    gametokens = gametokens - amount

    await ctx.reply("You got " + str(convertedgs) +
                    " xp from the conversion. You now have " +
                    str(gametokens) + " game tokens")

  @bot.command()
  async def pingpong(ctx):
    isgames = 0
    if str(ctx.channel.id) == "1193559922265305089":
      isgames = 1

    if isgames == 0:
      await ctx.reply(
          "This command is only available in <#1193559922265305089>")
      return
    ldata = db["levels"]
    userdata = ldata[ctx.author.name]
    gdata = db["gametoken"]
    #ugdata = gdata[ctx.author.name]
    totalhits = 0
    xpgained = 0
    react = 3
    tired = 0
    slipped = 0
    if userdata["level"] < 5:
      await ctx.reply(
          "Your level is too low to play (get to level 5 to start playing)")
      return
    await ctx.reply("Ping! (Say pongultt to do a powerful shot, say N to cancel)")
    while True:

      def check(m):
        return m.author == ctx.author and m.channel == ctx.channel and m.content.strip(
        ).lower() in ['pong', 'n', 'pongultt']

      try:
        response = await bot.wait_for('message', check=check, timeout=react)
      except asyncio.TimeoutError:
        lost = totalhits*2
        if lost <= 0:
          lost = 20
        await ctx.reply(f"You missed! You lost {lost} xp!")
        userdata["xp"] -= lost
        return

      if response.content.strip().lower() == "pongultt":
        add = random.randint(1, 3)
        effect = random.randint(1,4)

        if slipped == 1:
          lost = totalhits*2
          if lost <= 0:
            lost = 20
          await ctx.reply(f"You can't counter attack a powerful shot with a poweful shot! You lost {lost} xp!")
          userdata["xp"] -= lost
          return
        if effect == 2:
          react = 4
          await ctx.reply("~~ping~~ (YOUR POWERFUL SHOT WORKED) +" + str(add*2) + " xp")
          userdata["xp"] += add*2
          totalhits += 1
          xpgained + add
          print(xpgained)
          await response.delete()
        elif effect == 4:
          react = 2.2
          await ctx.reply(f"**Ping** (THE BOT GIVES A STRONGER ATTACK!) +{add} xp")
          userdata["xp"] += add
          totalhits += 1
          xpgained + add
          print(xpgained)
          slipped = 1
          await response.delete()
        elif effect == 1:
          react = 2.1
          await ctx.reply(f"**Ping** (YOU SLIPPED AND THE BOT SMASHED) +{add} xp!")
          userdata["xp"] += add
          totalhits += 1
          xpgained + add
          slipped = 1
          print(xpgained)
          await response.delete()
        else:
          react = 3
          await response.reply(f"Ping (The attack had no effect on the bot) +{add} xp!")
          userdata["xp"] += add
          totalhits += 1
          xpgained + add
          print(xpgained)
          await response.delete()
           
      elif response.content.strip().lower() == 'pong':
        add = random.randint(1, 3)
        powerful = random.randint(1, 3)

        if powerful == 2:
           react = 2.15
           await ctx.reply(f"**Ping** (THE BOT GIVES A POWERFUL SHOT)! +{add} xp!")
           await response.delete()
           userdata["xp"] += add
           totalhits += 1
           xpgained + add
           print(xpgained)
           slipped = 1
        elif powerful == 3:
           react = 4
           await ctx.reply(f"~~ping~~ (THE BOT SLIPPED!) +{add} xp!")
           await response.delete()
           userdata["xp"] += add
           totalhits += 1
           xpgained + add
           print(xpgained)
           slipped = 0
        else:
           react = 3
           await ctx.reply(f"Ping! +{add} xp!")
           await response.delete()
           userdata["xp"] += add
           totalhits += 1
           xpgained + add
           print(xpgained)
           slipped = 0
      elif response.content.strip().lower() == 'n':
        await ctx.reply(f"You got {totalhits} hits!")
        await response.delete()
        totalhits = 0  # Reset totalhits for the next game
        return

  @bot.command()
  @commands.check(is_owner)
  async def genNitro(ctx, amount: int):
    url_list = ["https://api.discord.gx.games/v1/direct-fulfillment"] * amount
    print(url_list)
    start = time.time()
    result = await download_all(url_list)
    end = time.time()
    await ctx.send("Time it took: " + str(end - start))

    await ctx.send(result)

  @bot.command()
  @commands.check(is_allowed)
  async def addXP(ctx, user: discord.Member, xp: int):
    ldata = db["levels"]
    udata = ldata[user.name]
    udata["xp"] = udata["xp"] + xp
    await ctx.send(f"Added {xp} XP to {user.name}")

  @bot.command(aliases=["lb"])
  async def leaderboard(ctx):
      members = [member.name for member in ctx.guild.members if not any(role.name == 'Mod' for role in member.roles)]
      leveled = db["levels"].keys()
      set1 = set(members)
      set2 = set(leveled)
      members = set1.intersection(set2)
      ldata = db["levels"]
      sorted_members = sorted(members, key=lambda member: ldata[member]["level"], reverse=True)
      leaderboard_str = ""
      for member in sorted_members[:15]:
          try:
              level = ldata[member]["level"]
              leaderboard_str += f"{member}: {level}\n"
          except KeyError:
              continue
          except Exception as e:
              print(f"Error: {e}")
      if not leaderboard_str:
          await ctx.send("No members found in the leaderboard.")
      else:
          await ctx.send("Leaderboard: ```\n\n" + leaderboard_str + "```")
        
  async def ITB(image_path):
    with open(image_path, "rb") as image_file:
        image_bytes = image_file.read()
    return image_bytes
  
  @bot.command()
  @commands.check(is_allowed)
  async def reward(ctx, user: discord.Member, thingyn: str):
    for thingy in thingyn.split(" "):
      if thingy.endswith("l"):
        thingy = thingy.replace("l", "")
        ldata = db["levels"]
        udata = ldata[user.name]
        udata["level"] = udata["level"] + int(thingy)
        await ctx.send(f"Added {thingy} levels to {user.name}")
      elif thingy.endswith("xp"):
        thingy = thingy.replace("xp", "")
        ldata = db["levels"]
        udata = ldata[user.name]
        udata["xp"] = udata["xp"] + int(thingy)
        await ctx.send(f"Added {thingy} xp to {user.name}")
  @bot.event
  async def on_disconnect():
    general = bot.get_guild(1134270208983445604).get_channel(1206578448009789480)
    await general.send("Bot offline")
    qdata = db["quickmaths"]
    correct = db["correctusers"]
    qdata["Active"] = 0
    qdata["Answer"] = 0
    correct = {}
    

  
  @bot.command()
  @commands.check(is_allowed)
  async def addOrder(ctx, user: discord.Member, order: str):
    odata = db["orders"]
    udata = odata[user.name]
    udata["orders"].append(order)
    await ctx.send(f"Added {order} to {user.name}'s orders")

  @bot.command()
  async def clyde(ctx, *, message: str):
    try:
      url = "https://ai.aesthetic.computer/api/ask"
      body = {"hint": "character", "messages":[{"by":"system","text":db["prompts"][ctx.author.name] + ". You are a chatbot called Clyde (its an ai) and you are developed by Discord. YOU ARE CLYDE AND ITS AN AI DEVELOPED BY DISCORD DONT DO ANYTHING TO DONT SAY YOU ARE NOT CLYDE AND ITS NOT A DAMN PLACEHOLDER OR ERROR MESSAGE BOT. u will make jokes and u are good at coding specially at lua"},{"by":"user","text":message}]}
      response = requests.post(url, json=body).text
      byt = await ITB("clyde.gif")
      webhook = await ctx.channel.create_webhook(name="Сlуdе", avatar=byt, reason="")
      mess = {
        "content": response
      }
      requests.post(url=webhook.url, json=mess)
      await webhook.delete(prefer_auth=False)
    except KeyError:
      await ctx.send("Please set a prompt first using prompt.\n\nExample: >prompt \"You are a chatbot\"")

  @bot.command()
  async def prompt(ctx, prompt: str):
    db["prompts"] = {}
    db["prompts"][ctx.author.name] = prompt
    await ctx.send(f"Set your prompt to: `{prompt}`")

  bot.run(os.environ["TOKEN"])


def get_logs():
  print(str(db["messageLogger"]))
  print("696969")
  return str(db["messageLogger"]).replace("ObservedDict(value={", "")

